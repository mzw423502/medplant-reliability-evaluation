# Paper 002 — code and frozen-output companion (v9 candidate)

This companion accompanies *Beyond Internal Accuracy: Cross-Source Generalization and Open-Set Reliability in Medicinal-Plant Image Classification*.

## What is included

- Auditing, group/split construction, evaluation, statistics and historical plotting source code.
- The formal ResNet-50 / ViT-B/16 training implementation and baseline / strong-augmentation configurations.
- Baseline frozen prediction tables and run/environment reports; supplementary result tables, including the mitigation extension.
- The strong-augmentation open-set implementation is retained in its original relative directory.

No third-party image pixels, self-collected images, model checkpoints, caches or credentials are included. Self-collected images remain available on reasonable request to the corresponding author. Code-release permission does not change image access permissions.

## Safe verification (no GPU, third-party packages or model execution)

From this folder run:

    python verify_package.py

This verifies file hashes and parses Python syntax only. It does not import or execute the scientific scripts, download data, train a model, select a threshold, or change results.

## Reproduction scope

The `predictions/` folder contains the existing baseline run outputs. The `supplementary_source/` folder contains the frozen table copies, including mitigation summaries. These can be inspected offline without trained models. Historical scripts refer to the original project directory layout; this compact archive is NOT an end-to-end executable reconstruction of that full project. Original input manifests, score files and image data are not all present at their expected paths. Do not run all scripts in bulk: some construct splits or launch training.

The historical `run_formal_frozen_feature_baseline.py` uses ResNet-18 and is not the formal ResNet-50 / ViT-B/16 primary experiment. The latter implementation is `scripts/run_formal_end_to_end.py`. Plot scripts are historical provenance, not a claim that they recreate every final manually assembled figure.

Recovered checkpoints do not consistently reproduce all frozen predictions and are excluded. No new inference or matched-training-source comparison is claimed by this package. Source code is supplied for method transparency; recovered-output reproducibility and complete training reproducibility are distinct.

## Dependencies and release status

See `DEPENDENCIES.json` for statically detected imports and `environment/` for original run environment records. The environment records describe the training host, not a verified installation on the reader's computer. No automatic environment installation or experiment runner is provided.

Author permission to release code was recorded on 2026-09-07. No repository has been created or uploaded in this operation. A public URL, versioned release and approved licence have NOT yet been assigned. This is a release candidate; do not describe it as an already published repository or as a fully tested reproduction package.
