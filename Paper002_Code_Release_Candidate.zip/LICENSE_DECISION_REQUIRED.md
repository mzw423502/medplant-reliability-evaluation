# Licence decision required

The author has permitted code uploading. A specific software licence has not yet been selected; this preparation step does not grant an invented licence. Confirm the licence with the relevant rights holders before public repository release. Third-party datasets retain their own licences; the software licence must not be applied to those data automatically.
