from pathlib import Path
import ast, hashlib, json
root = Path(__file__).resolve().parent
manifest = json.loads((root/'FILE_HASHES.json').read_text(encoding='utf-8'))
errors=[]
for item in manifest:
    p=root/item['path']
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:
        errors.append(item['path'])
for p in root.rglob('*.py'):
    ast.parse(p.read_text(encoding='utf-8-sig'), filename=str(p))
print(json.dumps({'files_checked':len(manifest),'hash_mismatches':errors,'syntax':'PASS','experiments_executed':False}))
raise SystemExit(bool(errors))
