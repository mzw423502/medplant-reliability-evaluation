from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader
from torchvision import transforms

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
import run_formal_end_to_end as formal  # noqa: E402


RUN_ROOT = ROOT / "PRESPECIFIED_MITIGATION_EXTENSION" / "01_strong_augmentation_runs"
OUT_ROOT = ROOT / "PRESPECIFIED_MITIGATION_EXTENSION" / "02_open_set_reaudit"
CONFIG_PATH = ROOT / "configs" / "mitigation_strong_augmentation_frozen_v1.json"
BASELINE_METRICS_PATH = (
    ROOT
    / "gpu_handoff_return_2026-08-18"
    / "06_open_set_reaudit_v2"
    / "final_metrics_all_runs.csv"
)
CHECKPOINT_NAME = "last_checkpoint.pt"
SELF_MANIFEST = ROOT / "03_数据与代码审计" / "自采开放集正式图像清单_v2.csv"

MODELS = ("resnet50", "vit_b_16")
SEEDS = (20260817, 20260818, 20260819)
MODES = ("748f_to_nnyt", "nnyt_to_748f", "combined_group_split")
METHODS = ("maximum_softmax_probability", "temperature_scaled_msp", "energy_score", "feature_distance")
SCORE_COLUMNS = {
    "maximum_softmax_probability": "msp_score",
    "temperature_scaled_msp": "temperature_scaled_msp_score",
    "energy_score": "energy_score",
    "feature_distance": "feature_distance",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError(f"No rows for {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def log_run(path: Path, message: str) -> None:
    line = f"{datetime.now(timezone.utc).isoformat()} {message}\n"
    with path.open("a", encoding="utf-8") as stream:
        stream.write(line)


def evaluation_transform(size: int):
    return transforms.Compose([
        transforms.Resize((size, size)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
    ])


def loader(rows, transform, labels, source, batch_size, device):
    return DataLoader(
        formal.ImageRows(rows, transform, labels, source),
        batch_size=batch_size,
        shuffle=False,
        num_workers=0,
        pin_memory=device.type == "cuda",
    )


def average_precision(labels: np.ndarray, scores: np.ndarray) -> float:
    positives = int(labels.sum())
    if positives == 0:
        return math.nan
    order = np.argsort(-scores, kind="stable")
    ranked = labels[order]
    precision = np.cumsum(ranked) / np.arange(1, len(ranked) + 1)
    return float((precision * ranked).sum() / positives)


def roc_points(labels: np.ndarray, scores: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    order = np.argsort(-scores, kind="stable")
    labels = labels[order]
    scores = scores[order]
    positives = int(labels.sum())
    negatives = len(labels) - positives
    if positives == 0 or negatives == 0:
        return np.asarray([math.nan]), np.asarray([math.nan])
    ends = np.r_[np.flatnonzero(np.diff(scores)), len(scores) - 1]
    tp = np.cumsum(labels)[ends]
    fp = (ends + 1) - tp
    tpr = np.r_[0.0, tp / positives, 1.0]
    fpr = np.r_[0.0, fp / negatives, 1.0]
    return fpr.astype(float), tpr.astype(float)


def auroc(labels: np.ndarray, scores: np.ndarray) -> float:
    fpr, tpr = roc_points(labels, scores)
    return float(np.trapezoid(tpr, fpr))


def fpr_at_95_tpr(labels: np.ndarray, scores: np.ndarray) -> float:
    fpr, tpr = roc_points(labels, scores)
    hits = np.flatnonzero(tpr >= 0.95)
    return float(fpr[hits[0]]) if len(hits) else math.nan


def oscr(known_scores: np.ndarray, known_correct: np.ndarray, unknown_scores: np.ndarray) -> float:
    scores = np.concatenate([known_scores, unknown_scores])
    is_unknown = np.concatenate([
        np.zeros(len(known_scores), dtype=np.int8),
        np.ones(len(unknown_scores), dtype=np.int8),
    ])
    is_correct_known = np.concatenate([
        known_correct.astype(np.int8),
        np.zeros(len(unknown_scores), dtype=np.int8),
    ])
    order = np.argsort(scores, kind="stable")
    scores = scores[order]
    is_unknown = is_unknown[order]
    is_correct_known = is_correct_known[order]
    ends = np.r_[np.flatnonzero(np.diff(scores)), len(scores) - 1]
    accepted_unknown = np.cumsum(is_unknown)[ends] / max(len(unknown_scores), 1)
    correct_known = np.cumsum(is_correct_known)[ends] / max(len(known_scores), 1)
    fpr = np.r_[0.0, accepted_unknown, 1.0]
    ccr = np.r_[0.0, correct_known, correct_known[-1] if len(correct_known) else 0.0]
    return float(np.trapezoid(ccr, fpr))


def balanced_threshold(known_scores: np.ndarray, unknown_scores: np.ndarray) -> tuple[float, float, float, float]:
    values = np.unique(np.concatenate([known_scores, unknown_scores]))
    if len(values) == 1:
        candidates = values
    else:
        candidates = np.r_[values[0] - 1e-12, (values[:-1] + values[1:]) / 2, values[-1] + 1e-12]
    best = None
    for threshold in candidates:
        known_acceptance = float(np.mean(known_scores < threshold))
        unknown_recall = float(np.mean(unknown_scores >= threshold))
        balanced = (known_acceptance + unknown_recall) / 2
        candidate = (balanced, known_acceptance, unknown_recall, float(threshold))
        if best is None or candidate[:2] > best[:2]:
            best = candidate
    assert best is not None
    return best[3], best[0], best[1], best[2]


def score_sets(probs, logits, features, temperature, centroids):
    normalized = features / np.linalg.norm(features, axis=1, keepdims=True).clip(min=1e-12)
    temp_probs = torch.softmax(torch.from_numpy(logits / temperature), dim=1).numpy()
    return {
        "maximum_softmax_probability": 1.0 - probs.max(axis=1),
        "temperature_scaled_msp": 1.0 - temp_probs.max(axis=1),
        "energy_score": -np.logaddexp.reduce(logits, axis=1),
        "feature_distance": 1.0 - (normalized @ centroids.T).max(axis=1),
    }


def fit_temperature(val_logits: np.ndarray, val_truth: np.ndarray) -> float:
    best_temperature, best_loss = 1.0, math.inf
    for temperature in np.linspace(0.5, 5.0, 91):
        scaled = val_logits / temperature
        log_probs = scaled - np.logaddexp.reduce(scaled, axis=1, keepdims=True)
        loss = float(-log_probs[np.arange(len(val_truth)), val_truth].mean())
        if loss < best_loss:
            best_temperature, best_loss = float(temperature), loss
    return best_temperature


def select_device(name: str) -> torch.device:
    if name == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA requested but unavailable")
        return torch.device("cuda")
    if name == "cpu":
        return torch.device("cpu")
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--models", nargs="+", choices=MODELS, default=list(MODELS))
    parser.add_argument("--seeds", nargs="+", type=int, choices=SEEDS, default=list(SEEDS))
    parser.add_argument("--modes", nargs="+", choices=MODES, default=list(MODES))
    parser.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()

    config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    if formal.sha256(CONFIG_PATH) != "8f5725f404222b38f27ae01c0f8dace011e785e886ca5a3444c0781ceecdcb81":
        raise RuntimeError("Frozen config hash mismatch")
    public_path = ROOT / config["public_manifest"]
    if formal.sha256(public_path) != config["public_manifest_sha256"] or formal.sha256(SELF_MANIFEST) != config["self_open_set_manifest_sha256"]:
        raise RuntimeError("Frozen manifest hash mismatch")

    public = formal.read_csv(public_path)
    self_rows = formal.read_csv(SELF_MANIFEST)
    calibration_rows = [row for row in self_rows if row["open_set_role"] == "unknown_calibration"]
    final_rows = [row for row in self_rows if row["open_set_role"] == "unknown_final_test"]
    if len(calibration_rows) != 378 or len(final_rows) != 1530:
        raise RuntimeError("Unexpected frozen self-data counts")
    classes = sorted({row["accepted_scientific_name"] for row in public})
    label_to_index = {label: index for index, label in enumerate(classes)}
    device = select_device(args.device)
    transform = evaluation_transform(int(config["image_size"]))
    OUT_ROOT.mkdir(parents=True, exist_ok=True)

    selected_runs = [(model, seed, mode) for model in args.models for seed in args.seeds for mode in args.modes]
    for run_index, (model_name, seed, mode) in enumerate(selected_runs, start=1):
        run_id = f"{model_name}_seed{seed}_{mode}"
        run_out = OUT_ROOT / "runs" / run_id
        done_path = run_out / "metrics.json"
        if args.resume and done_path.exists():
            print(f"[{run_index}/{len(selected_runs)}] resume skip {run_id}", flush=True)
            continue
        print(f"[{run_index}/{len(selected_runs)}] evaluate {run_id} on {device}", flush=True)
        source_dir = RUN_ROOT / model_name / f"seed_{seed}" / mode
        run_out.mkdir(parents=True, exist_ok=True)
        log_run(run_out / "run.log", f"start run_id={run_id} device={device}")
        report = json.loads((source_dir / "run_report.json").read_text(encoding="utf-8"))
        if report["config_sha256"] != formal.sha256(CONFIG_PATH) or report["unknown_final_test_images_loaded"] != 0:
            raise RuntimeError(f"Invalid source report: {run_id}")
        checkpoint = source_dir / CHECKPOINT_NAME
        saved = torch.load(checkpoint, map_location=device, weights_only=False)
        model, _ = formal.model_and_weights(model_name, False)
        model_classes = saved.get("classes", classes)
        if model_classes != classes:
            raise RuntimeError(f"Class order mismatch: {run_id}")
        formal.replace_classifier(model, len(classes))
        model.load_state_dict(saved["model"])
        model.to(device).eval()
        batch_size = int(config["batch_size"][model_name])
        amp = device.type == "cuda" and bool(config["mixed_precision"])
        train_rows, val_rows, test_rows = formal.scenario_rows(public, mode)

        train_probs, train_truth, _, train_logits, train_features = formal.infer(
            model, loader(train_rows, transform, label_to_index, "public", batch_size, device), device, amp
        )
        val_probs, val_truth, val_meta, val_logits, val_features = formal.infer(
            model, loader(val_rows, transform, label_to_index, "public", batch_size, device), device, amp
        )
        cal_probs, _, cal_meta, cal_logits, cal_features = formal.infer(
            model, loader(calibration_rows, transform, None, "self", batch_size, device), device, amp
        )
        test_probs, test_truth, test_meta, test_logits, test_features = formal.infer(
            model, loader(test_rows, transform, label_to_index, "public", batch_size, device), device, amp
        )
        final_probs, _, final_meta, final_logits, final_features = formal.infer(
            model, loader(final_rows, transform, None, "self", batch_size, device), device, amp
        )

        normalized_train = train_features / np.linalg.norm(train_features, axis=1, keepdims=True).clip(min=1e-12)
        centroids = []
        for class_index in range(len(classes)):
            centroid = normalized_train[train_truth == class_index].mean(axis=0)
            centroids.append(centroid / np.linalg.norm(centroid).clip(min=1e-12))
        centroids = np.asarray(centroids)
        temperature = fit_temperature(val_logits, val_truth)
        val_scores = score_sets(val_probs, val_logits, val_features, temperature, centroids)
        cal_scores = score_sets(cal_probs, cal_logits, cal_features, temperature, centroids)
        test_scores = score_sets(test_probs, test_logits, test_features, temperature, centroids)
        final_scores = score_sets(final_probs, final_logits, final_features, temperature, centroids)

        calibration_summary = []
        final_summary = []
        test_correct = test_probs.argmax(axis=1) == test_truth
        val_correct = val_probs.argmax(axis=1) == val_truth
        for method in METHODS:
            threshold, balanced, known_accept, unknown_recall = balanced_threshold(val_scores[method], cal_scores[method])
            cal_labels = np.r_[np.zeros(len(val_rows), dtype=np.int8), np.ones(len(calibration_rows), dtype=np.int8)]
            cal_all_scores = np.r_[val_scores[method], cal_scores[method]]
            final_labels = np.r_[np.zeros(len(test_rows), dtype=np.int8), np.ones(len(final_rows), dtype=np.int8)]
            final_all_scores = np.r_[test_scores[method], final_scores[method]]
            calibration_summary.append({
                "method": method,
                "threshold_balanced_accuracy": threshold,
                "calibration_balanced_accuracy": balanced,
                "known_validation_acceptance": known_accept,
                "unknown_calibration_recall": unknown_recall,
                "calibration_auroc": auroc(cal_labels, cal_all_scores),
                "calibration_aupr": average_precision(cal_labels, cal_all_scores),
                "calibration_fpr95": fpr_at_95_tpr(cal_labels, cal_all_scores),
                "calibration_oscr": oscr(val_scores[method], val_correct, cal_scores[method]),
            })
            final_summary.append({
                "method": method,
                "threshold_from_calibration": threshold,
                "known_test_acceptance": float(np.mean(test_scores[method] < threshold)),
                "final_unknown_recall": float(np.mean(final_scores[method] >= threshold)),
                "final_joint_auroc": auroc(final_labels, final_all_scores),
                "final_joint_aupr": average_precision(final_labels, final_all_scores),
                "final_joint_fpr95": fpr_at_95_tpr(final_labels, final_all_scores),
                "final_joint_oscr": oscr(test_scores[method], test_correct, final_scores[method]),
            })

        val_rows_out = []
        for index, row in enumerate(val_meta):
            val_rows_out.append({
                "path": row["path"], "accepted_scientific_name": row["accepted_scientific_name"],
                "near_duplicate_group_id": row["near_duplicate_group_id"], "correct": int(val_correct[index]),
                **{SCORE_COLUMNS[m]: float(val_scores[m][index]) for m in METHODS},
            })
        cal_rows_out = []
        for index, row in enumerate(cal_meta):
            cal_rows_out.append({
                "canonical_image_id": row["canonical_image_id"], "canonical_species_id": row["canonical_species_id"],
                "physical_leaf_id": row["physical_leaf_id"],
                **{SCORE_COLUMNS[m]: float(cal_scores[m][index]) for m in METHODS},
            })
        test_rows_out = []
        for index, row in enumerate(test_meta):
            test_rows_out.append({
                "path": row["path"], "accepted_scientific_name": row["accepted_scientific_name"],
                "near_duplicate_group_id": row["near_duplicate_group_id"], "correct": int(test_correct[index]),
                **{SCORE_COLUMNS[m]: float(test_scores[m][index]) for m in METHODS},
            })
        final_rows_out = []
        thresholds = {row["method"]: row["threshold_balanced_accuracy"] for row in calibration_summary}
        for index, row in enumerate(final_meta):
            final_rows_out.append({
                "canonical_image_id": row["canonical_image_id"], "canonical_species_id": row["canonical_species_id"],
                "physical_leaf_id": row["physical_leaf_id"],
                **{SCORE_COLUMNS[m]: float(final_scores[m][index]) for m in METHODS},
                **{f"{SCORE_COLUMNS[m]}_unknown_v2": int(final_scores[m][index] >= thresholds[m]) for m in METHODS},
            })
        write_csv(run_out / "known_validation_scores.csv", val_rows_out)
        write_csv(run_out / "unknown_calibration_scores.csv", cal_rows_out)
        write_csv(run_out / "known_test_scores.csv", test_rows_out)
        write_csv(run_out / "unknown_final_scores_v2.csv", final_rows_out)
        write_csv(run_out / "calibration_metrics.csv", calibration_summary)
        write_csv(run_out / "final_metrics.csv", final_summary)
        raw_path = run_out / "unknown_final_logits_features.npz"
        np.savez_compressed(raw_path, logits=final_logits, features=final_features)
        metrics = {
            "run_id": run_id, "model": model_name, "seed": seed, "mode": mode,
            "device": str(device), "temperature": temperature,
            "source_checkpoint": str(checkpoint.relative_to(ROOT)), "source_checkpoint_sha256": sha256(checkpoint),
            "unknown_final_logits_features_sha256": sha256(raw_path),
            "known_validation_images": len(val_rows), "unknown_calibration_images": len(calibration_rows),
            "known_test_images": len(test_rows), "unknown_final_images": len(final_rows),
            "threshold_rule": "maximize balanced accuracy on known validation plus unknown calibration; higher score means unknown",
            "calibration": calibration_summary, "final": final_summary,
        }
        done_path.write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
        log_run(
            run_out / "run.log",
            "complete source_checkpoint_sha256="
            f"{metrics['source_checkpoint_sha256']} final_joint_auroc="
            f"{[round(row['final_joint_auroc'], 6) for row in final_summary]}",
        )
        del model
        if device.type == "cuda":
            torch.cuda.empty_cache()

    metrics_files = sorted((OUT_ROOT / "runs").glob("*/metrics.json"))
    aggregate_calibration = []
    aggregate_final = []
    for path in metrics_files:
        result = json.loads(path.read_text(encoding="utf-8"))
        identity = {key: result[key] for key in ("run_id", "model", "seed", "mode")}
        aggregate_calibration.extend([{**identity, **row} for row in result["calibration"]])
        aggregate_final.extend([{**identity, **row} for row in result["final"]])
    write_csv(OUT_ROOT / "calibration_metrics_all_runs.csv", aggregate_calibration)
    write_csv(OUT_ROOT / "final_metrics_all_runs.csv", aggregate_final)
    comparison_written = False
    if len(metrics_files) == 18:
        comparison_written = write_baseline_comparison()
    summary = {
        "status": "STRONG_AUGMENTATION_OPEN_SET_REAUDIT_COMPLETE" if len(metrics_files) == 18 else "STRONG_AUGMENTATION_OPEN_SET_REAUDIT_PARTIAL",
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "completed_runs": len(metrics_files), "expected_runs": 18,
        "source_training_reused": True, "models_retrained": False,
        "old_results_overwritten": False, "device": str(device),
        "baseline_comparison_written": comparison_written,
        "final_unknown_predictions_source": "strong-augmentation checkpoints",
    }
    (OUT_ROOT / "reaudit_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    artifacts = []
    for path in sorted(OUT_ROOT.rglob("*")):
        if path.is_file() and path.name != "artifact_hashes.csv":
            artifacts.append({"relative_path": str(path.relative_to(OUT_ROOT)), "bytes": path.stat().st_size, "sha256": sha256(path)})
    write_csv(OUT_ROOT / "artifact_hashes.csv", artifacts)
    print(json.dumps(summary, ensure_ascii=False), flush=True)


def write_baseline_comparison() -> bool:
    if not BASELINE_METRICS_PATH.exists():
        print(f"Baseline metrics missing: {BASELINE_METRICS_PATH}", file=sys.stderr, flush=True)
        return False
    baseline_rows = formal.read_csv(BASELINE_METRICS_PATH)
    baseline = {(row["run_id"], row["method"]): row for row in baseline_rows}
    extension_rows = formal.read_csv(OUT_ROOT / "final_metrics_all_runs.csv")
    numeric_columns = [
        "threshold_from_calibration",
        "known_test_acceptance",
        "final_unknown_recall",
        "final_joint_auroc",
        "final_joint_aupr",
        "final_joint_fpr95",
        "final_joint_oscr",
    ]
    comparison_rows = []
    for row in extension_rows:
        key = (row["run_id"], row["method"])
        base = baseline.get(key)
        output = {
            "run_id": row["run_id"],
            "model": row["model"],
            "seed": row["seed"],
            "mode": row["mode"],
            "method": row["method"],
        }
        if base is None:
            output["baseline_match"] = "missing"
            comparison_rows.append(output)
            continue
        output["baseline_match"] = "matched"
        for column in numeric_columns:
            base_value = float(base[column])
            extension_value = float(row[column])
            output[f"baseline_{column}"] = base_value
            output[f"strong_aug_{column}"] = extension_value
            output[f"delta_{column}"] = extension_value - base_value
        comparison_rows.append(output)
    write_csv(OUT_ROOT / "baseline_vs_strong_augmentation_final_metrics.csv", comparison_rows)
    (OUT_ROOT / "comparison_summary.json").write_text(
        json.dumps(
            {
                "baseline_metrics": str(BASELINE_METRICS_PATH.relative_to(ROOT)),
                "baseline_runs": len(baseline_rows),
                "strong_augmentation_runs": len(extension_rows),
                "matched_run_method_rows": sum(1 for row in comparison_rows if row.get("baseline_match") == "matched"),
                "delta_convention": "strong_augmentation - baseline",
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return True


if __name__ == "__main__":
    main()
