from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
from collections import defaultdict

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RUN_ROOT = ROOT / "gpu_handoff_return_2026-08-18" / "04_primary_runs"
OPEN_ROOT = ROOT / "gpu_handoff_return_2026-08-18" / "06_open_set_reaudit_v2"
OUT = ROOT / "04_关键结果账本" / "v2_paper_statistics"
MODELS = ("resnet50", "vit_b_16")
SEEDS = (20260817, 20260818, 20260819)
MODES = ("748f_to_nnyt", "nnyt_to_748f", "combined_group_split")


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader(); w.writerows(rows)


def macro_f1(rows):
    labels = sorted(set(r["true_label"] for r in rows))
    vals = []
    for label in labels:
        tp = sum(r["true_label"] == label and r["predicted_label"] == label for r in rows)
        fn = sum(r["true_label"] == label and r["predicted_label"] != label for r in rows)
        fp = sum(r["true_label"] != label and r["predicted_label"] == label for r in rows)
        p = tp / (tp + fp) if tp + fp else 0.0
        rec = tp / (tp + fn) if tp + fn else 0.0
        vals.append(2 * p * rec / (p + rec) if p + rec else 0.0)
    return float(np.mean(vals)) if vals else float("nan")


def bootstrap_group_macro_f1(rows, replicates=2000, seed=20260819):
    strata = defaultdict(lambda: defaultdict(list))
    for r in rows:
        strata[r["true_label"]][r.get("near_duplicate_group_id", r["path"])].append(r)
    rng = np.random.default_rng(seed)
    estimates = []
    for _ in range(replicates):
        sample = []
        for groups in strata.values():
            keys = list(groups)
            for key in rng.choice(keys, size=len(keys), replace=True):
                sample.extend(groups[str(key)])
        estimates.append(macro_f1(sample))
    return float(np.quantile(estimates, .025)), float(np.quantile(estimates, .975))


def main():
    run_rows = []
    species_rows = []
    for model in MODELS:
        for seed in SEEDS:
            for mode in MODES:
                p = RUN_ROOT / model / f"seed_{seed}" / mode / "test_predictions.csv"
                rows = read_csv(p)
                f1 = macro_f1(rows)
                lo, hi = bootstrap_group_macro_f1(rows, seed=seed + len(mode))
                run_rows.append({"model": model, "seed": seed, "mode": mode, "images": len(rows), "macro_f1": f1, "bootstrap_ci_low": lo, "bootstrap_ci_high": hi})
                by = defaultdict(list)
                for r in rows: by[r["true_label"]].append(r)
                for species, sr in sorted(by.items()):
                    species_rows.append({"model": model, "seed": seed, "mode": mode, "species": species, "images": len(sr), "macro_f1_species_one_vs_rest": macro_f1(sr) if len(by) == 1 else float(np.mean([int(r["true_label"] == r["predicted_label"]) for r in sr])), "accuracy": float(np.mean([int(r["true_label"] == r["predicted_label"]) for r in sr]))})
    write_csv(OUT / "closed_set_run_statistics.csv", run_rows)
    write_csv(OUT / "closed_set_species_statistics.csv", species_rows)

    # Paired seed summaries for cross-source direction and internal test.
    summary = []
    for model in MODELS:
        for mode in MODES:
            vals = [r for r in run_rows if r["model"] == model and r["mode"] == mode]
            x = np.asarray([r["macro_f1"] for r in vals])
            summary.append({"model": model, "mode": mode, "n_seeds": len(x), "mean_macro_f1": float(x.mean()), "sd_macro_f1": float(x.std(ddof=1)), "min_macro_f1": float(x.min()), "max_macro_f1": float(x.max())})
    write_csv(OUT / "closed_set_model_mode_summary.csv", summary)

    open_rows = read_csv(OPEN_ROOT / "final_metrics_all_runs.csv")
    open_summary = []
    for model in MODELS:
        for method in sorted(set(r["method"] for r in open_rows)):
            vals = [r for r in open_rows if r["model"] == model and r["method"] == method]
            fields = ["known_test_acceptance", "final_unknown_recall", "final_joint_auroc", "final_joint_aupr", "final_joint_fpr95", "final_joint_oscr"]
            out = {"model": model, "method": method, "n_runs": len(vals)}
            for field in fields:
                x = np.asarray([float(r[field]) for r in vals]); out[field + "_mean"] = float(x.mean()); out[field + "_sd"] = float(x.std(ddof=1))
            open_summary.append(out)
    write_csv(OUT / "open_set_v2_model_method_summary.csv", open_summary)

    meta = {"status": "PAPER_STATISTICS_V1_COMPLETE", "closed_set_runs": len(run_rows), "closed_set_species_rows": len(species_rows), "open_set_rows": len(open_rows), "bootstrap_replicates": 2000, "bootstrap_unit": "near_duplicate_group_id stratified by species"}
    (OUT / "statistics_summary.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(meta, ensure_ascii=False))


if __name__ == "__main__": main()
