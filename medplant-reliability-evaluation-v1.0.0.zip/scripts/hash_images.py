#!/usr/bin/env python3
"""Compute cryptographic and perceptual hashes for downloaded audit images."""
from __future__ import annotations

import csv
import hashlib
import sys
from pathlib import Path

import numpy as np
from PIL import Image, ImageOps

ROOT = Path(__file__).resolve().parents[1]
SCAN = [ROOT / "data" / "raw" / "748f8jkphb_v3" / "Medicinal Leaf dataset",
        ROOT / "data" / "raw" / "nnytj2v3n5_v1",
        ROOT / "data" / "raw" / "h7x86smwtp_v4",
        ROOT / "data" / "extracted" / "t9rns2gmr3_v1"]
EXT = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp"}


def bits_hex(bits: np.ndarray) -> str:
    return f"{int(''.join('1' if x else '0' for x in bits.ravel()), 2):016x}"


def dhash(gray: Image.Image) -> str:
    a = np.asarray(gray.resize((9, 8), Image.Resampling.LANCZOS), dtype=np.int16)
    return bits_hex(a[:, 1:] > a[:, :-1])


def phash(gray: Image.Image) -> str:
    a = np.asarray(gray.resize((32, 32), Image.Resampling.LANCZOS), dtype=np.float64)
    n = 32
    k = np.arange(n)[:, None]
    x = np.arange(n)[None, :]
    d = np.cos(np.pi * (x + .5) * k / n)
    coeff = d[:8] @ a @ d[:8].T
    med = np.median(coeff.ravel()[1:])
    return bits_hex(coeff > med)


def infer(path: Path) -> tuple[str, str, str, str]:
    rel = path.relative_to(ROOT).as_posix()
    parts = path.parts
    dataset = next((p for p in parts if p.endswith(("_v1", "_v3", "_v4"))), "")
    kind = "augmented" if "Augmented Images-" in parts else "non_augmented" if "Non Augmented Images-" in parts else "not_declared_augmented"
    split = next((p.lower() for p in parts if p.lower() in {"train", "test", "validation", "val"}), "")
    if dataset.startswith("t9rns2gmr3"):
        marker = "Augmented" if kind == "augmented" else "Non Augmented"
        label = parts[parts.index(marker) + 1] if marker in parts else ""
    else:
        label = path.parent.name
    return dataset, kind, split, label


def main() -> int:
    paths = [p for root in SCAN if root.exists() for p in root.rglob("*") if p.is_file() and p.suffix.lower() in EXT]
    out = ROOT / "results"; out.mkdir(exist_ok=True)
    fields = ["dataset", "kind", "split", "label", "path", "bytes", "width", "height", "sha256", "dhash64", "phash64", "error"]
    with (out / "image_hashes.csv").open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader()
        for i, path in enumerate(paths, 1):
            dataset, kind, split, label = infer(path)
            row = dict(dataset=dataset, kind=kind, split=split, label=label,
                       path=path.relative_to(ROOT).as_posix(), bytes=path.stat().st_size,
                       width="", height="", sha256="", dhash64="", phash64="", error="")
            try:
                data = path.read_bytes(); row["sha256"] = hashlib.sha256(data).hexdigest()
                with Image.open(path) as im:
                    im = ImageOps.exif_transpose(im); row["width"], row["height"] = im.size
                    gray = im.convert("L"); row["dhash64"] = dhash(gray); row["phash64"] = phash(gray)
            except Exception as exc:
                row["error"] = repr(exc)
            writer.writerow(row)
            if i % 2000 == 0: print(i, len(paths), flush=True)
    print("completed", len(paths))
    return 0


if __name__ == "__main__": sys.exit(main())
