from __future__ import annotations

import csv
import hashlib
import io
import json
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = ROOT / "图"
OUT_ROOT = ROOT / "03_数据与代码审计"
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff"}

CORRECTED_IDS = {"SP001", "SP002", "SP004", "SP005", "SP006"}
CONFLICT_REMAP = {
    "SP003": "SP045", "SP004": "SP052", "SP005": "SP053",
    "SP006": "SP054", "SP007": "SP055", "SP008": "SP056",
    "SP009": "SP057", "SP010": "SP058", "SP011": "SP059",
    "SP012": "SP060", "SP013": "SP061", "SP014": "SP062",
}
TEN_PLANT_REMAP = {
    "SP015": "SP063", "SP016": "SP064", "SP017": "SP065",
    "SP018": "SP066", "SP019": "SP008",
}
INCOMING_20260818 = {
    "SP046_雄黄兰_2026-08-18.zip": ("SP046", 0),
    "SP047_八宝景天_2026-08-18.zip": ("SP013", 3),
    "SP048_草麻黄_2026-08-18.zip": ("SP048", 0),
    "SP049_半夏_2026-08-18.zip": ("SP049", 0),
    "SP050_铃兰_2026-08-18.zip": ("SP050", 0),
    "SP051_天人菊_2026-08-18.zip": ("SP051", 0),
    "SP020_石菖蒲_2026-08-18.zip": ("SP067", 0),
    "SP021_韭菜（韭菜花）_2026-08-18.zip": ("SP068", 0),
    "SP022_芍药_2026-08-18.zip": ("SP069", 0),
    "SP023_东北红豆杉_2026-08-18.zip": ("SP070", 0),
    "SP024_八宝（八宝景天）_2026-08-18.zip": ("SP071", 0),
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_csv(zf: zipfile.ZipFile, name: str) -> list[dict[str, str]]:
    return list(csv.DictReader(io.StringIO(zf.read(name).decode("utf-8-sig"))))


packages: list[dict[str, object]] = []

# Stable top-level series. Metadata-corrected packages supersede the five older copies.
for path in sorted(DATA_ROOT.glob("SP*.zip")):
    source_id = path.name.split("_", 1)[0]
    if source_id in CORRECTED_IDS:
        continue
    packages.append({"path": path, "canonical_id": source_id, "role": "top_level_authority"})

for source_id in sorted(CORRECTED_IDS):
    matches = sorted((DATA_ROOT / "已补学名").glob(f"{source_id}_*.zip"))
    if len(matches) != 1:
        raise RuntimeError(f"Expected one corrected ZIP for {source_id}, found {len(matches)}")
    packages.append({"path": matches[0], "canonical_id": source_id, "role": "metadata_corrected_authority"})

# Twelve distinct species whose original IDs collided with the stable top-level series.
conflict_12 = DATA_ROOT / "待整理_ID冲突批次_2026-08-16"
for source_id, canonical_id in CONFLICT_REMAP.items():
    matches = sorted(conflict_12.glob(f"{source_id}_*.zip"))
    matches = [path for path in matches if not (DATA_ROOT / path.name).exists()]
    if len(matches) != 1:
        raise RuntimeError(f"Expected one conflict ZIP for {source_id}, found {len(matches)}")
    packages.append({"path": matches[0], "canonical_id": canonical_id, "role": "remapped_new_species"})

# Four new species plus ten additional Lonicera japonica physical leaves.
conflict_5 = DATA_ROOT / "待整理_ID冲突批次_2026-08-17"
for source_id, canonical_id in TEN_PLANT_REMAP.items():
    matches = sorted(conflict_5.glob(f"{source_id}_*.zip"))
    if len(matches) != 1:
        raise RuntimeError(f"Expected one ten-plant conflict ZIP for {source_id}, found {len(matches)}")
    packages.append({"path": matches[0], "canonical_id": canonical_id, "role": "remapped_ten_plant"})

# New official packages. Preserve SP046/SP048-SP051 where available; merge the
# new H. spectabile package into SP013 with new physical-leaf numbers.
incoming = DATA_ROOT / "新增批次_2026-08-18"
for filename, (canonical_id, plant_offset) in INCOMING_20260818.items():
    path = incoming / filename
    if not path.is_file():
        raise RuntimeError(f"Missing verified incoming ZIP: {path}")
    packages.append({
        "path": path,
        "canonical_id": canonical_id,
        "plant_offset": plant_offset,
        "role": "incoming_20260818_merged_existing_species" if plant_offset else "incoming_20260818_new_species",
    })

manifest_rows: list[dict[str, object]] = []
mapping_rows: list[dict[str, object]] = []

for package in sorted(packages, key=lambda item: (str(item["canonical_id"]), str(item["path"]))):
    path = Path(package["path"])
    canonical_id = str(package["canonical_id"])
    role = str(package["role"])
    plant_offset = int(package.get("plant_offset", 0))
    with zipfile.ZipFile(path) as zf:
        bad = zf.testzip()
        if bad:
            raise RuntimeError(f"CRC failure in {path}: {bad}")
        species_rows = read_csv(zf, "species.csv")
        source_manifest = read_csv(zf, "manifest.csv")
        if len(species_rows) != 1:
            raise RuntimeError(f"Expected one species row in {path}")
        species = species_rows[0]
        original_species_id = species["species_id"]
        image_by_name = {
            Path(info.filename).name: info
            for info in zf.infolist()
            if not info.is_dir() and Path(info.filename).suffix.lower() in IMAGE_EXT
        }
        if len(image_by_name) != len(source_manifest):
            raise RuntimeError(f"Image/manifest mismatch in {path}")

        plant_map: dict[str, str] = {}
        original_plants = sorted({row["plant_id"] for row in source_manifest})
        for original_plant_id in original_plants:
            suffix = original_plant_id.rsplit("_P", 1)[-1]
            original_number = int(suffix)
            if original_species_id == "SP019" and canonical_id == "SP008":
                canonical_number = original_number + 3
            else:
                canonical_number = original_number + plant_offset
            plant_map[original_plant_id] = f"{canonical_id}_P{canonical_number:02d}"

        mapping_rows.append({
            "source_zip": path.relative_to(ROOT).as_posix(),
            "source_zip_sha256": sha256_file(path),
            "package_role": role,
            "original_species_id": original_species_id,
            "canonical_species_id": canonical_id,
            "original_chinese_name": species.get("chinese_name", ""),
            "canonical_chinese_name": species.get("chinese_name", ""),
            "scientific_name_as_supplied": species.get("scientific_name", ""),
            "declared_plant_count": species.get("plant_count", ""),
            "plant_id_rule": (
                "P01-P10 -> P04-P13" if original_species_id == "SP019" and canonical_id == "SP008"
                else f"add {plant_offset} to P number" if plant_offset
                else "preserve P number"
            ),
            "status": "ACTIVE_DERIVED_MAPPING",
        })

        for row in source_manifest:
            original_image_id = row["image_id"]
            info = image_by_name.get(Path(row["relative_path"]).name)
            if info is None:
                raise RuntimeError(f"Missing image for {original_image_id} in {path}")
            data = zf.read(info)
            with Image.open(io.BytesIO(data)) as image:
                width, height = image.size
            canonical_plant_id = plant_map[row["plant_id"]]
            view_code = row["view_code"]
            canonical_image_id = f"{canonical_plant_id}_{view_code}"
            manifest_rows.append({
                "canonical_image_id": canonical_image_id,
                "canonical_species_id": canonical_id,
                "original_species_id": original_species_id,
                "original_label": row.get("chinese_name", species.get("chinese_name", "")),
                "scientific_name_as_supplied": row.get("scientific_name", species.get("scientific_name", "")),
                "canonical_plant_id": canonical_plant_id,
                "physical_leaf_id": canonical_plant_id,
                "original_plant_id": row["plant_id"],
                "view_code": view_code,
                "view_name": row.get("view_name", ""),
                "background": row.get("background", ""),
                "distance_class": row.get("distance_class", ""),
                "captured_at": row.get("captured_at", ""),
                "original_filename": row.get("original_filename", ""),
                "source_zip": path.relative_to(ROOT).as_posix(),
                "source_entry": info.filename,
                "package_role": role,
                "width": width,
                "height": height,
                "bytes": len(data),
                "sha256": sha256_bytes(data),
            })

image_ids = [str(row["canonical_image_id"]) for row in manifest_rows]
hashes = [str(row["sha256"]) for row in manifest_rows]
groups = defaultdict(list)
for row in manifest_rows:
    groups[str(row["physical_leaf_id"])].append(row)

if len(image_ids) != len(set(image_ids)):
    duplicates = [key for key, count in Counter(image_ids).items() if count > 1]
    raise RuntimeError(f"Duplicate canonical image IDs: {duplicates[:5]}")
if len(hashes) != len(set(hashes)):
    raise RuntimeError("Canonical selection contains exact duplicate image hashes")
bad_groups = {key: len(value) for key, value in groups.items() if len(value) != 6}
if bad_groups:
    raise RuntimeError(f"Physical leaf groups not equal to six images: {bad_groups}")

species_summary: list[dict[str, object]] = []
by_species = defaultdict(list)
for row in manifest_rows:
    by_species[str(row["canonical_species_id"])].append(row)
for species_id, rows in sorted(by_species.items()):
    leaf_ids = sorted({str(row["physical_leaf_id"]) for row in rows})
    species_summary.append({
        "canonical_species_id": species_id,
        "chinese_name": rows[0]["original_label"],
        "scientific_name_as_supplied": rows[0]["scientific_name_as_supplied"],
        "physical_leaf_groups": len(leaf_ids),
        "images": len(rows),
        "collection_tier": "ten_plant_robustness" if len(leaf_ids) >= 10 else "three_plant_breadth",
        "source_zip_count": len({str(row["source_zip"]) for row in rows}),
    })

OUT_ROOT.mkdir(parents=True, exist_ok=True)
for path, rows in [
    (OUT_ROOT / "自采数据稳定ID映射.csv", mapping_rows),
    (OUT_ROOT / "自采数据规范化图像清单.csv", manifest_rows),
    (OUT_ROOT / "自采数据规范化物种汇总.csv", species_summary),
]:
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

summary = {
    "canonical_species": len(species_summary),
    "physical_leaf_groups": len(groups),
    "unique_images": len(manifest_rows),
    "exact_duplicate_hashes": len(hashes) - len(set(hashes)),
    "groups_with_non_six_image_count": len(bad_groups),
    "ten_plant_or_larger_species": sum(int(row["physical_leaf_groups"]) >= 10 for row in species_summary),
    "three_plant_species": sum(int(row["physical_leaf_groups"]) == 3 for row in species_summary),
    "source_packages": len(packages),
    "excluded_historical_batch_exports": True,
}
(OUT_ROOT / "自采数据规范化摘要.json").write_text(
    json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
)
print(json.dumps(summary, ensure_ascii=False))
