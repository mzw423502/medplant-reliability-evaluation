from __future__ import annotations

import csv
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader
from torchvision import transforms

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import run_formal_end_to_end as formal  # noqa: E402


RUN_ROOT = ROOT / "gpu_handoff_return_2026-08-18" / "04_primary_runs"
OUT_ROOT = ROOT / "gpu_handoff_return_2026-08-18" / "05_final_results" / "unknown_final_test"
CONFIG_PATH = ROOT / "configs" / "formal_experiment_frozen_v1.json"
MANIFEST_PATH = ROOT / "03_数据与代码审计" / "自采开放集正式图像清单_v2.csv"


def expected_runs() -> list[tuple[str, int, str]]:
    return [(m, s, mode) for m in ("resnet50", "vit_b_16") for s in (20260817, 20260818, 20260819) for mode in ("748f_to_nnyt", "nnyt_to_748f", "combined_group_split")]


def make_transform(size: int):
    return transforms.Compose([transforms.Resize((size, size)), transforms.ToTensor(), transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])


def quantile(values: np.ndarray, q: float) -> float:
    return float(np.quantile(values, q)) if len(values) else math.nan


def main() -> None:
    config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    config_hash = formal.sha256(CONFIG_PATH)
    reports = {}
    for model, seed, mode in expected_runs():
        directory = RUN_ROOT / model / f"seed_{seed}" / mode
        report_path = directory / "run_report.json"
        checkpoint_path = directory / "last_checkpoint.pt"
        if not report_path.exists() or not checkpoint_path.exists():
            raise SystemExit(f"Missing finalized run: {model} seed={seed} mode={mode}")
        report = json.loads(report_path.read_text(encoding="utf-8"))
        if report.get("config_sha256") != config_hash:
            raise SystemExit(f"Frozen config hash mismatch: {model} seed={seed} mode={mode}")
        if report.get("unknown_final_test_images_loaded") != 0:
            raise SystemExit("Final unknown data was loaded before freeze")
        reports[(model, seed, mode)] = report
    all_rows = formal.read_csv(MANIFEST_PATH)
    final_rows = [row for row in all_rows if row["open_set_role"] == "unknown_final_test"]
    if not final_rows:
        raise SystemExit("No unknown_final_test rows found")
    classes = sorted({row["accepted_scientific_name"] for row in formal.read_csv(ROOT / config["public_manifest"])})
    label_to_index = {name: i for i, name in enumerate(classes)}
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if config.get("device") == "cuda" and device.type != "cuda":
        raise SystemExit("CUDA is required by the frozen config")
    OUT_ROOT.mkdir(parents=True, exist_ok=True)
    summary_rows = []
    for model_name, seed, mode in expected_runs():
        directory = RUN_ROOT / model_name / f"seed_{seed}" / mode
        report = reports[(model_name, seed, mode)]
        saved = torch.load(directory / "last_checkpoint.pt", map_location=device, weights_only=False)
        model, _ = formal.model_and_weights(model_name, False)
        model_classes = saved.get("classes", classes)
        formal.replace_classifier(model, len(model_classes))
        model.load_state_dict(saved["model"])
        model.to(device).eval()
        batch_size = int(config["batch_size"][model_name])
        loader = DataLoader(formal.ImageRows(final_rows, make_transform(int(config["image_size"])), None, "self"), batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=True)
        probs, _, meta, logits, features = formal.infer(model, loader, device, device.type == "cuda" and bool(config["mixed_precision"]))
        mode_rows = formal.scenario_rows(formal.read_csv(ROOT / config["public_manifest"]), mode)[0]
        train_loader = DataLoader(formal.ImageRows(mode_rows, make_transform(int(config["image_size"])), label_to_index, "public"), batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=True)
        _, train_truth, _, _, train_features = formal.infer(model, train_loader, device, device.type == "cuda" and bool(config["mixed_precision"]))
        normalized_train = train_features / np.linalg.norm(train_features, axis=1, keepdims=True).clip(min=1e-12)
        centroids = []
        for class_index in range(len(model_classes)):
            centroid = normalized_train[train_truth == class_index].mean(axis=0)
            centroids.append(centroid / np.linalg.norm(centroid).clip(min=1e-12))
        centroids = np.asarray(centroids)
        normalized_features = features / np.linalg.norm(features, axis=1, keepdims=True).clip(min=1e-12)
        scores = {
            "maximum_softmax_probability": 1.0 - probs.max(axis=1),
            "temperature_scaled_msp": 1.0 - torch.softmax(torch.from_numpy(logits / float(report["open_set"]["temperature"])), dim=1).numpy().max(axis=1),
            "energy_score": -np.logaddexp.reduce(logits, axis=1),
            "feature_distance": 1.0 - (normalized_features @ centroids.T).max(axis=1),
        }
        prediction_path = OUT_ROOT / f"{model_name}_seed{seed}_{mode}_predictions.csv"
        with prediction_path.open("w", encoding="utf-8-sig", newline="") as stream:
            fields = ["canonical_image_id", "canonical_species_id", "physical_leaf_id", "source_entry", "predicted_label", "max_softmax", "msp_score", "temperature_scaled_msp_score", "energy_score", "feature_distance", "msp_score_unknown", "temperature_scaled_msp_score_unknown", "energy_score_unknown", "feature_distance_unknown"]
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            for row, probability, meta_row, index in zip(final_rows, probs, meta, range(len(final_rows))):
                output = {key: row.get(key, "") for key in fields[:4]}
                output.update({"predicted_label": model_classes[int(probability.argmax())], "max_softmax": float(probability.max())})
                output_names = {
                    "maximum_softmax_probability": "msp_score",
                    "temperature_scaled_msp": "temperature_scaled_msp_score",
                    "energy_score": "energy_score",
                    "feature_distance": "feature_distance",
                }
                for name, score in scores.items():
                    threshold = float(report["open_set"]["methods"][name]["threshold_from_known_validation_95th_percentile"])
                    output[output_names[name]] = float(score[index])
                    output[f"{output_names[name]}_unknown"] = int(score[index] >= threshold)
                writer.writerow(output)
        for name, score in scores.items():
            threshold = float(report["open_set"]["methods"][name]["threshold_from_known_validation_95th_percentile"])
            summary_rows.append({"model": model_name, "seed": seed, "mode": mode, "method": name, "threshold_frozen": threshold, "images": len(score), "unknown_decisions": int(np.sum(score >= threshold)), "unknown_rate": float(np.mean(score >= threshold)), "score_p05": quantile(score, 0.05), "score_median": quantile(score, 0.5), "score_p95": quantile(score, 0.95)})
    summary = {"status": "UNKNOWN_FINAL_TEST_EVALUATED_ONCE", "completed_at_utc": datetime.now(timezone.utc).isoformat(), "images": len(final_rows), "runs": len(expected_runs()), "thresholds_source": "frozen run_report.json only", "final_unknown_test_images_loaded_before_this_script": 0}
    (OUT_ROOT / "unknown_final_test_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    with (OUT_ROOT / "unknown_final_test_summary.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summary_rows[0]))
        writer.writeheader()
        writer.writerows(summary_rows)
    (OUT_ROOT / "FINAL_UNKNOWN_TEST_EVALUATED_ONCE.txt").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
