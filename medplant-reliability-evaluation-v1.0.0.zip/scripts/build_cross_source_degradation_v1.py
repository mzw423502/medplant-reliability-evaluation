from pathlib import Path
import csv, json
from collections import defaultdict
import numpy as np
ROOT=Path(__file__).resolve().parents[1]; RUN=ROOT/'gpu_handoff_return_2026-08-18'/'04_primary_runs'; OUT=ROOT/'04_关键结果账本'/'v2_paper_statistics'
MODELS=['resnet50','vit_b_16']; SEEDS=[20260817,20260818,20260819]; CROSS=['748f_to_nnyt','nnyt_to_748f']; INTERNAL='combined_group_split'
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def f1(rows,labels=None):
 labels=labels or sorted(set(r['true_label'] for r in rows)); z=[]
 for lab in labels:
  tp=sum(r['true_label']==lab and r['predicted_label']==lab for r in rows); fn=sum(r['true_label']==lab and r['predicted_label']!=lab for r in rows); fp=sum(r['true_label']!=lab and r['predicted_label']==lab for r in rows); p=tp/(tp+fp) if tp+fp else 0; rec=tp/(tp+fn) if tp+fn else 0; z.append(2*p*rec/(p+rec) if p+rec else 0)
 return float(np.mean(z))
def boot(rows,n=2000,seed=1):
 strata=defaultdict(lambda:defaultdict(list))
 for r in rows:strata[r['true_label']][r['near_duplicate_group_id']].append(r)
 rng=np.random.default_rng(seed); out=[]; labels=sorted(strata)
 for _ in range(n):
  sample=[]
  for lab in labels:
   gs=strata[lab]; keys=list(gs); sample.extend(x for k in rng.choice(keys,size=len(keys),replace=True) for x in gs[str(k)])
  out.append(f1(sample,labels))
 return np.asarray(out)
rows=[]
for model in MODELS:
 for seed in SEEDS:
  cache={mode:read(RUN/model/f'seed_{seed}'/mode/'test_predictions.csv') for mode in [INTERNAL]+CROSS}; bi={mode:boot(cache[mode],seed=seed+hash(mode)%10000) for mode in cache}; base=float(f1(cache[INTERNAL])); baseb=bi[INTERNAL]
  for mode in CROSS:
   val=float(f1(cache[mode])); diff=base-val; rel=100*diff/base if base else np.nan; db=baseb-bi[mode]
   rows.append({'model':model,'seed':seed,'direction':mode,'internal_macro_f1':base,'cross_source_macro_f1':val,'absolute_drop':diff,'relative_degradation_percent':rel,'internal_bootstrap_ci_low':float(np.quantile(baseb,.025)),'internal_bootstrap_ci_high':float(np.quantile(baseb,.975)),'cross_bootstrap_ci_low':float(np.quantile(bi[mode],.025)),'cross_bootstrap_ci_high':float(np.quantile(bi[mode],.975)),'drop_bootstrap_ci_low':float(np.quantile(db,.025)),'drop_bootstrap_ci_high':float(np.quantile(db,.975)),'bootstrap_replicates':2000,'bootstrap_unit':'near_duplicate_group_id stratified by species','baseline_definition':'same model and seed combined_group_split internal test; independent source/test group bootstrap'} )
with (OUT/'CROSS_SOURCE_DEGRADATION_FULL.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary=[]
for model in MODELS:
 for mode in CROSS:
  q=[x for x in rows if x['model']==model and x['direction']==mode]; summary.append({'model':model,'direction':mode,'n_seeds':3,'mean_internal_macro_f1':np.mean([float(x['internal_macro_f1']) for x in q]),'mean_cross_macro_f1':np.mean([float(x['cross_source_macro_f1']) for x in q]),'mean_absolute_drop':np.mean([float(x['absolute_drop']) for x in q]),'mean_relative_degradation_percent':np.mean([float(x['relative_degradation_percent']) for x in q]),'seed_range_absolute_drop':f"{min(float(x['absolute_drop']) for x in q):.3f}-{max(float(x['absolute_drop']) for x in q):.3f}"})
with (OUT/'CROSS_SOURCE_DEGRADATION_SUMMARY.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
print(json.dumps({'status':'CROSS_SOURCE_DEGRADATION_COMPLETE','rows':len(rows),'bootstrap_replicates':2000},ensure_ascii=False))
