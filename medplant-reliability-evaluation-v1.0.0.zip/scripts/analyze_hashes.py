#!/usr/bin/env python3
"""Summarize exact duplicates, split leakage, and perceptual-hash sensitivity."""
from __future__ import annotations

import csv
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def hd(a: str, b: str) -> int: return (int(a, 16) ^ int(b, 16)).bit_count()


rows = list(csv.DictReader((ROOT / "results" / "image_hashes.csv").open(encoding="utf-8-sig")))
valid = [r for r in rows if not r["error"]]
out = ROOT / "results"

# Exact duplicate groups and cross-split/cross-dataset flags.
by_sha = defaultdict(list)
for r in valid: by_sha[r["sha256"]].append(r)
exact = []
for digest, group in by_sha.items():
    if len(group) < 2: continue
    exact.append({"sha256": digest, "count": len(group),
                  "datasets": "|".join(sorted(set(r["dataset"] for r in group))),
                  "splits": "|".join(sorted(set(r["split"] for r in group if r["split"]))),
                  "labels": "|".join(sorted(set(r["label"] for r in group))),
                  "paths": "|".join(r["path"] for r in group)})
with (out / "exact_duplicate_groups.csv").open("w", newline="", encoding="utf-8-sig") as h:
    w = csv.DictWriter(h, fieldnames=list(exact[0]) if exact else ["sha256","count","datasets","splits","labels","paths"]); w.writeheader(); w.writerows(exact)

# BDMediLeaves augmented-to-non-augmented nearest neighbour distances.
t9 = [r for r in valid if r["dataset"].startswith("t9rns2gmr3")]
raw_by_label = defaultdict(list)
for r in t9:
    if r["kind"] == "non_augmented": raw_by_label[r["label"]].append(r)
nearest = []
for i, r in enumerate((x for x in t9 if x["kind"] == "augmented"), 1):
    candidates = raw_by_label[r["label"]]
    best = min(candidates, key=lambda q: (hd(r["phash64"], q["phash64"]), hd(r["dhash64"], q["dhash64"])))
    nearest.append({"augmented_path": r["path"], "raw_path": best["path"], "label": r["label"],
                    "phash_distance": hd(r["phash64"], best["phash64"]),
                    "dhash_distance": hd(r["dhash64"], best["dhash64"]),
                    "raw_split": best["split"]})
with (out / "t9_augmented_nearest_raw.csv").open("w", newline="", encoding="utf-8-sig") as h:
    w=csv.DictWriter(h,fieldnames=list(nearest[0])); w.writeheader(); w.writerows(nearest)

thresholds = [0, 2, 4, 6, 8, 10, 12, 16]
sens = []
for threshold in thresholds:
    p = sum(int(r["phash_distance"]) <= threshold for r in nearest)
    both = sum(int(r["phash_distance"]) <= threshold and int(r["dhash_distance"]) <= threshold for r in nearest)
    sens.append({"threshold": threshold, "augmented_total": len(nearest), "phash_matches": p, "phash_and_dhash_matches": both})
with (out / "t9_threshold_sensitivity.csv").open("w", newline="", encoding="utf-8-sig") as h:
    w=csv.DictWriter(h,fieldnames=list(sens[0])); w.writeheader(); w.writerows(sens)

# Candidate pairs for bounded manual review, stratified by pHash distance.
sample = []
for distance in range(0, 17):
    bucket = [r for r in nearest if int(r["phash_distance"]) == distance]
    sample.extend(bucket[:5])
with (out / "manual_review_candidates.csv").open("w", newline="", encoding="utf-8-sig") as h:
    w=csv.DictWriter(h,fieldnames=list(sample[0])); w.writeheader(); w.writerows(sample)

# Conservative grouping edges: all byte-identical pairs/groups plus perceptual
# pairs at the manually reviewed pHash<=6 AND dHash<=6 boundary. These are
# duplicate/near-duplicate clusters, never asserted to be physical leaves.
edges=[]
for x in exact:
    paths=x['paths'].split('|')
    for p in paths[1:]: edges.append({'path_a':paths[0],'path_b':p,'basis':'sha256_exact','phash_distance':0,'dhash_distance':0})
for r in nearest:
    if int(r['phash_distance']) <= 6 and int(r['dhash_distance']) <= 6:
        edges.append({'path_a':r['augmented_path'],'path_b':r['raw_path'],'basis':'manual_reviewed_phash_and_dhash_le6',
                      'phash_distance':r['phash_distance'],'dhash_distance':r['dhash_distance']})
with (out / 'conservative_group_edges.csv').open('w',newline='',encoding='utf-8-sig') as h:
    w=csv.DictWriter(h,fieldnames=list(edges[0]));w.writeheader();w.writerows(edges)

# Existing split leakage inside non-augmented BDMediLeaves.
raw = [r for r in t9 if r["kind"] == "non_augmented"]
leak = []
for i, a in enumerate(raw):
    for b in raw[i+1:]:
        if a["label"] != b["label"] or not a["split"] or a["split"] == b["split"]: continue
        pd, dd = hd(a["phash64"], b["phash64"]), hd(a["dhash64"], b["dhash64"])
        if a["sha256"] == b["sha256"] or (pd <= 6 and dd <= 6):
            leak.append({"path_a":a["path"],"split_a":a["split"],"path_b":b["path"],"split_b":b["split"],
                         "label":a["label"],"exact":a["sha256"]==b["sha256"],"phash_distance":pd,"dhash_distance":dd})
with (out / "t9_cross_split_candidates.csv").open("w", newline="", encoding="utf-8-sig") as h:
    fields=list(leak[0]) if leak else ["path_a","split_a","path_b","split_b","label","exact","phash_distance","dhash_distance"]
    w=csv.DictWriter(h,fieldnames=fields); w.writeheader(); w.writerows(leak)

summary = {
    "images": len(valid), "errors": len(rows)-len(valid), "exact_duplicate_groups": len(exact),
    "exact_duplicate_images": sum(int(x["count"]) for x in exact),
    "cross_dataset_exact_groups": sum("|" in x["datasets"] for x in exact),
    "cross_split_exact_groups": sum("|" in x["splits"] for x in exact),
    "t9_augmented": len(nearest), "t9_raw": len(raw), "t9_cross_split_candidates_le6_both": len(leak),
}
(out / "hash_audit_summary.json").write_text(__import__('json').dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
print(summary)
