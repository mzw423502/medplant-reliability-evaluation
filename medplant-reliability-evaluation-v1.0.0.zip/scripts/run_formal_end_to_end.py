from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import platform
import random
import sys
import time
import zipfile
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageOps
from torch import nn
from torch.utils.data import DataLoader, Dataset
from torchvision import models, transforms


ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True, warn_only=True)


class ImageRows(Dataset):
    def __init__(self, rows, transform, label_to_index, source):
        self.rows = rows
        self.transform = transform
        self.label_to_index = label_to_index
        self.source = source
        self.zip_handles: dict[str, zipfile.ZipFile] = {}

    def __len__(self):
        return len(self.rows)

    def _load(self, row):
        if self.source == "public":
            path = ROOT / row["path"]
            with Image.open(path) as image:
                return ImageOps.exif_transpose(image).convert("RGB")
        zip_path = row["source_zip"]
        if zip_path not in self.zip_handles:
            self.zip_handles[zip_path] = zipfile.ZipFile(ROOT / zip_path)
        payload = self.zip_handles[zip_path].read(row["source_entry"])
        with Image.open(io.BytesIO(payload)) as image:
            return ImageOps.exif_transpose(image).convert("RGB")

    def __getitem__(self, index):
        row = self.rows[index]
        image = self.transform(self._load(row))
        label = -1 if self.label_to_index is None else self.label_to_index[row["accepted_scientific_name"]]
        return image, label, index


def model_and_weights(name: str, pretrained: bool):
    if name == "resnet50":
        weights = models.ResNet50_Weights.IMAGENET1K_V2 if pretrained else None
        return models.resnet50(weights=weights), weights
    if name == "vit_b_16":
        weights = models.ViT_B_16_Weights.IMAGENET1K_V1 if pretrained else None
        return models.vit_b_16(weights=weights), weights
    raise ValueError(f"Unsupported model: {name}")


def replace_classifier(model: nn.Module, classes: int) -> None:
    if hasattr(model, "fc"):
        model.fc = nn.Linear(model.fc.in_features, classes)
    elif hasattr(model, "heads"):
        model.heads.head = nn.Linear(model.heads.head.in_features, classes)
    else:
        raise RuntimeError("Could not locate classifier head")


def classifier_parameters(model: nn.Module):
    if hasattr(model, "fc"):
        return model.fc.parameters()
    return model.heads.parameters()


def limit_stratified(rows, label_field: str, limit: int | None, seed: int):
    if limit is None or len(rows) <= limit:
        return rows
    groups = defaultdict(list)
    for row in rows:
        groups[row[label_field]].append(row)
    rng = random.Random(seed)
    for values in groups.values():
        rng.shuffle(values)
    selected = []
    while len(selected) < limit:
        progress = False
        for label in sorted(groups):
            if groups[label] and len(selected) < limit:
                selected.append(groups[label].pop())
                progress = True
        if not progress:
            break
    return selected


def scenario_rows(public, mode: str):
    dataset = np.asarray([row["dataset_id"] for row in public])
    split = np.asarray([row["formal_split"] for row in public])
    if mode == "748f_to_nnyt":
        return ([r for r in public if r["dataset_id"] == "748f8jkphb_v3" and r["formal_split"] == "train"],
                [r for r in public if r["dataset_id"] == "748f8jkphb_v3" and r["formal_split"] == "validation"],
                [r for r in public if r["dataset_id"] == "nnytj2v3n5_v1"])
    if mode == "nnyt_to_748f":
        return ([r for r in public if r["dataset_id"] == "nnytj2v3n5_v1" and r["formal_split"] == "train"],
                [r for r in public if r["dataset_id"] == "nnytj2v3n5_v1" and r["formal_split"] == "validation"],
                [r for r in public if r["dataset_id"] == "748f8jkphb_v3"])
    if mode == "combined_group_split":
        return ([r for r in public if r["formal_split"] == "train"],
                [r for r in public if r["formal_split"] == "validation"],
                [r for r in public if r["formal_split"] == "internal_test"])
    raise ValueError(f"Unsupported training mode: {mode}")


def metrics(truth, prediction, probabilities, classes):
    confusion = np.zeros((classes, classes), dtype=np.int64)
    for left, right in zip(truth, prediction):
        confusion[int(left), int(right)] += 1
    recalls, f1s = [], []
    for index in range(classes):
        tp = confusion[index, index]
        fn = confusion[index].sum() - tp
        fp = confusion[:, index].sum() - tp
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        recalls.append(recall)
        f1s.append(2 * precision * recall / (precision + recall) if precision + recall else 0.0)
    one_hot = np.eye(classes)[truth]
    return {
        "top1_accuracy": float(np.mean(truth == prediction)),
        "balanced_accuracy": float(np.mean(recalls)),
        "macro_f1": float(np.mean(f1s)),
        "brier_score": float(np.mean(np.sum((probabilities - one_hot) ** 2, axis=1))),
    }


def ece(truth, probabilities, bins=15):
    confidence = probabilities.max(axis=1)
    prediction = probabilities.argmax(axis=1)
    total = len(truth)
    result = 0.0
    for left, right in zip(np.linspace(0, 1, bins + 1)[:-1], np.linspace(0, 1, bins + 1)[1:]):
        mask = (confidence >= left) & (confidence < right if right < 1 else confidence <= right)
        if mask.any():
            result += mask.mean() * abs((prediction[mask] == truth[mask]).mean() - confidence[mask].mean())
    return float(result)


def average_precision(labels, scores):
    positives = int(labels.sum())
    if positives == 0:
        return float("nan")
    order = np.argsort(-scores, kind="stable")
    ranked = labels[order]
    precision = np.cumsum(ranked) / np.arange(1, len(ranked) + 1)
    return float((precision * ranked).sum() / positives)


def auroc(labels, scores):
    positives = labels == 1
    n_pos, n_neg = int(positives.sum()), int((~positives).sum())
    if not n_pos or not n_neg:
        return float("nan")
    order = np.argsort(scores, kind="stable")
    ranks = np.empty(len(scores), dtype=float)
    ranks[order] = np.arange(1, len(scores) + 1)
    return float((ranks[positives].sum() - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg))


@torch.inference_mode()
def forward_logits_features(model, images):
    if hasattr(model, "fc"):
        x = model.relu(model.bn1(model.conv1(images)))
        x = model.maxpool(x)
        x = model.layer1(x)
        x = model.layer2(x)
        x = model.layer3(x)
        x = model.layer4(x)
        features = torch.flatten(model.avgpool(x), 1)
        return model.fc(features), features
    x = model._process_input(images)
    batch_class_token = model.class_token.expand(x.shape[0], -1, -1)
    x = torch.cat([batch_class_token, x], dim=1)
    x = model.encoder(x)
    features = x[:, 0]
    return model.heads(features), features


def infer(model, loader, device, amp_enabled):
    probabilities, logits_all, features_all, truths, indices = [], [], [], [], []
    model.eval()
    for images, labels, batch_rows in loader:
        with torch.amp.autocast("cuda", enabled=amp_enabled):
            logits, features = forward_logits_features(model, images.to(device, non_blocking=True))
        logits = logits.float()
        probabilities.append(torch.softmax(logits, dim=1).cpu().numpy())
        logits_all.append(logits.cpu().numpy())
        features_all.append(features.float().cpu().numpy())
        truths.extend(labels.numpy().tolist())
        indices.extend(batch_rows.numpy().tolist())
    rows = [loader.dataset.rows[index] for index in indices]
    return (np.concatenate(probabilities), np.asarray(truths, dtype=np.int64), rows,
            np.concatenate(logits_all), np.concatenate(features_all))


def train_one(model, train_loader, val_loader, optimizer, criterion, scaler, device, epochs, accum, amp_enabled, checkpoint, log_path):
    best_score, best_epoch, stale = -math.inf, 0, 0
    history = []
    for epoch in range(1, epochs + 1):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        running, steps = 0.0, 0
        for step, (images, labels, _) in enumerate(train_loader, start=1):
            with torch.amp.autocast("cuda", enabled=amp_enabled):
                loss = criterion(model(images.to(device, non_blocking=True)), labels.to(device, non_blocking=True)) / accum
            scaler.scale(loss).backward()
            if step % accum == 0 or step == len(train_loader):
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad(set_to_none=True)
            running += float(loss.detach()) * accum
            steps += 1
        val_probs, val_truth, _, _, _ = infer(model, val_loader, device, amp_enabled)
        val_metrics = metrics(val_truth, val_probs.argmax(1), val_probs, val_probs.shape[1])
        record = {"epoch": epoch, "train_loss": running / max(steps, 1), **{f"val_{k}": v for k, v in val_metrics.items()}, "learning_rate": optimizer.param_groups[0]["lr"]}
        history.append(record)
        with log_path.open("a", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(record))
            if stream.tell() == 0:
                writer.writeheader()
            writer.writerow(record)
        if val_metrics["macro_f1"] > best_score + 1e-12:
            best_score, best_epoch, stale = val_metrics["macro_f1"], epoch, 0
            torch.save({"model": model.state_dict(), "optimizer": optimizer.state_dict(), "epoch": epoch}, checkpoint)
        else:
            stale += 1
        if stale >= 8:
            break
    return best_epoch, history


def open_set_method_result(name, scores, labels, known_scores, calibration_rows):
    threshold = float(np.quantile(known_scores, 0.05))
    fpr95 = float(np.mean(scores[len(known_scores):] < threshold))
    return {
        "unknown_calibration_aupr": average_precision(labels, scores),
        "unknown_calibration_auroc": auroc(labels, scores),
        "fpr95_unknown_as_known": fpr95,
        "threshold_from_known_validation_95th_percentile": threshold,
        "calibration_images": len(calibration_rows),
        "final_unknown_test_images_loaded": 0,
    }


def evaluate_open_set(val_probs, val_logits, val_features, val_truth, calibration_rows, calibration_probs, calibration_logits, calibration_features, train_features, train_truth):
    labels = np.concatenate([np.zeros(len(val_probs), dtype=np.int64), np.ones(len(calibration_probs), dtype=np.int64)])
    known_msp = 1.0 - val_probs.max(axis=1)
    unknown_msp = 1.0 - calibration_probs.max(axis=1)
    results = {"maximum_softmax_probability": open_set_method_result("msp", np.concatenate([known_msp, unknown_msp]), labels, known_msp, calibration_rows)}
    temperatures = np.linspace(0.5, 5.0, 91)
    best_temperature, best_loss = 1.0, float("inf")
    for temperature in temperatures:
        scaled = val_logits / temperature
        log_probs = scaled - np.logaddexp.reduce(scaled, axis=1, keepdims=True)
        loss = float(-log_probs[np.arange(len(val_truth)), val_truth].mean())
        if loss < best_loss:
            best_loss, best_temperature = loss, float(temperature)
    val_temp = torch.softmax(torch.from_numpy(val_logits / best_temperature), dim=1).numpy()
    cal_temp = torch.softmax(torch.from_numpy(calibration_logits / best_temperature), dim=1).numpy()
    results["temperature_scaled_msp"] = open_set_method_result("temperature", np.concatenate([1 - val_temp.max(1), 1 - cal_temp.max(1)]), labels, 1 - val_temp.max(1), calibration_rows)
    energy_val = -np.logaddexp.reduce(val_logits, axis=1)
    energy_cal = -np.logaddexp.reduce(calibration_logits, axis=1)
    results["energy_score"] = open_set_method_result("energy", np.concatenate([energy_val, energy_cal]), labels, energy_val, calibration_rows)
    normalized_train = train_features / np.linalg.norm(train_features, axis=1, keepdims=True).clip(min=1e-12)
    centroids = []
    for class_index in range(val_probs.shape[1]):
        centroid = normalized_train[train_truth == class_index].mean(axis=0)
        centroids.append(centroid / np.linalg.norm(centroid).clip(min=1e-12))
    centroids = np.asarray(centroids)
    val_norm = val_features / np.linalg.norm(val_features, axis=1, keepdims=True).clip(min=1e-12)
    cal_norm = calibration_features / np.linalg.norm(calibration_features, axis=1, keepdims=True).clip(min=1e-12)
    distance_val = 1 - (val_norm @ centroids.T).max(axis=1)
    distance_cal = 1 - (cal_norm @ centroids.T).max(axis=1)
    results["feature_distance"] = open_set_method_result("feature_distance", np.concatenate([distance_val, distance_cal]), labels, distance_val, calibration_rows)
    return {"methods": results, "temperature": best_temperature, "final_unknown_test_images_loaded": 0}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--mode", required=True)
    parser.add_argument("--output-root", default="gpu_handoff_return_2026-08-18/04_primary_runs")
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    config_path = ROOT / args.config
    config = json.loads(config_path.read_text(encoding="utf-8"))
    if config.get("status") not in {"FROZEN_FOR_FORMAL_TRAINING", "GPU_SMOKE_NOT_FOR_PAPER", "PRESPECIFIED_MITIGATION_EXTENSION"}:
        raise RuntimeError("Config is not frozen or explicitly marked as smoke")
    if args.model not in config["models_primary"]:
        raise RuntimeError("Model is not allowed by config")
    if args.mode not in config["known_training_modes"]:
        raise RuntimeError("Mode is not allowed by config")
    if args.seed not in config["seeds"]:
        raise RuntimeError("Seed is not allowed by config")
    public_path = ROOT / config["public_manifest"]
    self_path = ROOT / config["self_open_set_manifest"]
    if sha256(public_path) != config["public_manifest_sha256"] or sha256(self_path) != config["self_open_set_manifest_sha256"]:
        raise RuntimeError("Frozen manifest hash mismatch")
    public = read_csv(public_path)
    self_rows = read_csv(self_path)
    calibration = [row for row in self_rows if row["open_set_role"] == "unknown_calibration"]
    if any(row["open_set_role"] == "unknown_final_test" for row in calibration):
        raise RuntimeError("Final unknown rows entered the calibration loader")
    set_seed(args.seed)
    classes = sorted({row["accepted_scientific_name"] for row in public})
    label_to_index = {name: i for i, name in enumerate(classes)}
    train_rows, val_rows, test_rows = scenario_rows(public, args.mode)
    train_rows = limit_stratified(train_rows, "accepted_scientific_name", config.get("smoke_max_train_images") if args.smoke else None, args.seed)
    val_rows = limit_stratified(val_rows, "accepted_scientific_name", config.get("smoke_max_validation_images") if args.smoke else None, args.seed + 1)
    calibration = limit_stratified(calibration, "canonical_species_id", config.get("smoke_max_unknown_calibration_images") if args.smoke else None, args.seed + 2)
    image_size = int(config["image_size"])
    weights = model_and_weights(args.model, bool(config["pretrained"]))[1]
    mean = [0.485, 0.456, 0.406]
    std = [0.229, 0.224, 0.225]
    train_steps = [
        transforms.RandomResizedCrop(image_size, scale=(0.8, 1.0)),
        transforms.RandomHorizontalFlip(p=0.5),
    ]
    if config.get("augmentation_profile") == "strong_color_blur_grayscale_v1":
        train_steps.extend([
            transforms.ColorJitter(brightness=0.4, contrast=0.4, saturation=0.4, hue=0.1),
            transforms.RandomApply([transforms.GaussianBlur(kernel_size=3, sigma=(0.1, 2.0))], p=0.2),
            transforms.RandomGrayscale(p=0.1),
        ])
    train_steps.extend([
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])
    train_transform = transforms.Compose(train_steps)
    eval_transform = transforms.Compose([
        transforms.Resize((image_size, image_size)),
        transforms.ToTensor(),
        transforms.Normalize(mean, std),
    ])
    batch_size = int(config["batch_size"][args.model] if isinstance(config["batch_size"], dict) else config["batch_size"])
    accum = int(config["gradient_accumulation_steps"][args.model] if isinstance(config["gradient_accumulation_steps"], dict) else config["gradient_accumulation_steps"])
    train_loader = DataLoader(ImageRows(train_rows, train_transform, label_to_index, "public"), batch_size=batch_size, shuffle=True, num_workers=0, pin_memory=torch.cuda.is_available())
    train_eval_loader = DataLoader(ImageRows(train_rows, eval_transform, label_to_index, "public"), batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=torch.cuda.is_available())
    val_loader = DataLoader(ImageRows(val_rows, eval_transform, label_to_index, "public"), batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=torch.cuda.is_available())
    cal_loader = DataLoader(ImageRows(calibration, eval_transform, None, "self"), batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=torch.cuda.is_available())
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if config.get("device") == "cuda" and device.type != "cuda":
        raise RuntimeError("CUDA is required by this config")
    model, _ = model_and_weights(args.model, bool(config["pretrained"]))
    replace_classifier(model, len(classes))
    model.to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=float(config["learning_rate"]), weight_decay=float(config["weight_decay"]))
    criterion = nn.CrossEntropyLoss()
    amp_enabled = device.type == "cuda" and bool(config["mixed_precision"])
    scaler = torch.amp.GradScaler("cuda", enabled=amp_enabled)
    output = ROOT / args.output_root / args.model / f"seed_{args.seed}" / args.mode
    output.mkdir(parents=True, exist_ok=True)
    (output / "config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    checkpoint = output / "best_checkpoint.pt"
    start = time.time()
    best_epoch, history = train_one(model, train_loader, val_loader, optimizer, criterion, scaler, device, int(config["epochs"]), accum, amp_enabled, checkpoint, output / "train_log.csv")
    saved = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(saved["model"])
    val_probs, val_truth, val_meta, val_logits, val_features = infer(model, val_loader, device, amp_enabled)
    test_loader = DataLoader(ImageRows(test_rows, eval_transform, label_to_index, "public"), batch_size=batch_size, shuffle=False, num_workers=0, pin_memory=torch.cuda.is_available())
    test_probs, test_truth, test_meta, _, _ = infer(model, test_loader, device, amp_enabled)
    cal_probs, _, cal_meta, cal_logits, cal_features = infer(model, cal_loader, device, amp_enabled)
    _, train_truth, _, _, train_features = infer(model, train_eval_loader, device, amp_enabled)
    test_prediction = test_probs.argmax(1)
    test_metrics = metrics(test_truth, test_prediction, test_probs, len(classes))
    test_metrics["ece"] = ece(test_truth, test_probs)
    prediction_rows = []
    for row, truth, prediction, probs in zip(test_meta, test_truth, test_prediction, test_probs):
        prediction_rows.append({"path": row.get("path", ""), "dataset_id": row.get("dataset_id", ""), "near_duplicate_group_id": row.get("near_duplicate_group_id", ""), "true_label": classes[int(truth)], "predicted_label": classes[int(prediction)], "max_softmax": float(probs.max()), "unknown_score_msp": float(1 - probs.max()), "correct": int(truth == prediction)})
    with (output / "test_predictions.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(prediction_rows[0]))
        writer.writeheader()
        writer.writerows(prediction_rows)
    open_result = evaluate_open_set(val_probs, val_logits, val_features, val_truth, calibration, cal_probs, cal_logits, cal_features, train_features, train_truth)
    report = {"run_class": config["status"], "paper_use": "PROHIBITED" if args.smoke else "FORMAL", "config": str(config_path.relative_to(ROOT)), "config_sha256": sha256(config_path), "model": args.model, "seed": args.seed, "mode": args.mode, "device": str(device), "train_images": len(train_rows), "validation_images": len(val_rows), "test_images": len(test_rows), "unknown_calibration_images_loaded": len(calibration), "unknown_final_test_images_loaded": 0, "best_epoch": best_epoch, "metrics": test_metrics, "open_set": open_result, "elapsed_seconds": time.time() - start, "peak_memory_bytes": torch.cuda.max_memory_allocated(device) if device.type == "cuda" else 0, "environment": {"python": sys.version, "platform": platform.platform(), "torch": torch.__version__, "torchvision": __import__("torchvision").__version__, "cuda_runtime": torch.version.cuda, "gpu": torch.cuda.get_device_name(0) if device.type == "cuda" else "NONE"}}
    (output / "run_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    torch.save({"model": model.state_dict(), "classes": classes, "config_sha256": report["config_sha256"]}, output / "last_checkpoint.pt")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
