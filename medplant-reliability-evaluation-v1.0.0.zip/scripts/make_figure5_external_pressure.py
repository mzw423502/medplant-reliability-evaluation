from pathlib import Path
import csv
from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'08_重绘主图'/'Figure5_external_pressure'; OUT.mkdir(parents=True,exist_ok=True)
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
manifest=read(ROOT/'03_数据与代码审计'/'自采开放集正式图像清单_v2.csv'); final=[r for r in manifest if r['open_set_role']=='unknown_final_test']; cal=[r for r in manifest if r['open_set_role']=='unknown_calibration']
species=defaultdict(set)
for r in manifest: species[r['accepted_scientific_name']].add(r['physical_leaf_id'])
groups=np.array([len(v) for v in species.values()]);
pred=read(ROOT/'gpu_handoff_return_2026-08-18'/'06_open_set_reaudit_v2'/'runs'/'resnet50_seed20260817_748f_to_nnyt'/'unknown_final_scores_v2.csv')
by=defaultdict(list)
for r in pred: by[r['canonical_species_id']].append(int(r['feature_distance_unknown_v2']))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'savefig.dpi':600,'axes.spines.top':False,'axes.spines.right':False})
blue='#1764A5'; orange='#D97706'; teal='#008C95'
fig,axs=plt.subplots(1,3,figsize=(8.4,2.9),gridspec_kw={'width_ratios':[1.0,1.0,1.25]})
ax=axs[0]; roles=[('unknown_calibration',cal,teal),('unknown_final_test',final,orange)]; vals=[len(set(r['accepted_scientific_name'] for r in rows)) for _,rows,_ in roles]; bars=ax.bar([0,1],vals,color=[teal,orange],width=.55);ax.set_xticks([0,1],['Calibration\nunknown','Final-test\nunknown']);ax.set_ylabel('Species count');ax.set_title('Two independent unknown roles',loc='left',weight='normal');ax.grid(axis='y',color='#D9DEE5',lw=.5);ax.set_axisbelow(True);ax.text(-.16,1.04,'a',transform=ax.transAxes,weight='bold',fontsize=11)
for b,v in zip(bars,vals):ax.text(b.get_x()+b.get_width()/2,v+.7,str(v),ha='center',fontsize=8)
ax=axs[1]; bins=[1,2,3,4,5,6,7,8,9,10]; counts=[int(np.sum(groups==b)) for b in bins]; ax.bar(bins,counts,color=blue,width=.75);ax.axvline(3.5,color='#59636E',ls='--',lw=.8);ax.set_xlabel('Physical leaf groups per species');ax.set_ylabel('Species count');ax.set_title('Sampling depth varies by species',loc='left',weight='normal');ax.grid(axis='y',color='#D9DEE5',lw=.5);ax.set_axisbelow(True);ax.text(-.16,1.04,'b',transform=ax.transAxes,weight='bold',fontsize=11)
ax=axs[2]; ids=sorted(by); rates=np.array([np.mean(by[i]) for i in ids]); order=np.argsort(rates); y=np.arange(len(ids)); ax.scatter(rates[order],y,color=orange,s=12);ax.set_xlim(-.03,1.03);ax.set_yticks([]);ax.set_xlabel('Feature-distance unknown recall');ax.set_title('Unknown recall varies by species',loc='left',weight='normal',fontsize=8.5);ax.grid(axis='x',color='#D9DEE5',lw=.5);ax.set_axisbelow(True);ax.text(-.14,1.04,'c',transform=ax.transAxes,weight='bold',fontsize=11);ax.text(.02,.02,f'n={len(ids)} final species',transform=ax.transAxes,fontsize=7,color='#59636E')
fig.tight_layout(w_pad=1.8);fig.savefig(OUT/'Figure5_external_pressure.png',dpi=600);fig.savefig(OUT/'Figure5_external_pressure.pdf');fig.savefig(OUT/'Figure5_external_pressure.svg');print(OUT/'Figure5_external_pressure.png')
