from pathlib import Path
import csv
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT=Path(__file__).resolve().parents[1]
STAT=ROOT/'04_关键结果账本'/'v2_paper_statistics'
OPEN=ROOT/'gpu_handoff_return_2026-08-18'/'06_open_set_reaudit_v2'
OUT=ROOT/'08_重绘主图'/'Figure1_reliability'
OUT.mkdir(parents=True,exist_ok=True)

def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

closed=read(STAT/'closed_set_run_statistics.csv')
opened=read(OPEN/'final_metrics_all_runs.csv')
rows=[]
for r in closed:
    rows.append({'model':r['model'],'seed':r['seed'],'mode':r['mode'],'macro_f1':r['macro_f1'],'ci_low':r['bootstrap_ci_low'],'ci_high':r['bootstrap_ci_high']})
with (OUT/'figure1_closed_set_points.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with (OUT/'figure1_open_set_points.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(opened[0]));w.writeheader();w.writerows(opened)

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':600})
blue='#1764A5'; orange='#D97706'; teal='#008C95'; gray='#59636E'
fig,axs=plt.subplots(1,2,figsize=(7.0,3.15),gridspec_kw={'width_ratios':[1.18,1]})
ax=axs[0]
order=['combined_group_split','748f_to_nnyt','nnyt_to_748f']; labels=['Combined\ngroup test','748f → nnyt','nnyt → 748f']; xpos=np.arange(3)
for j,model in enumerate(['resnet50','vit_b_16']):
    col=blue if model=='resnet50' else orange
    for i,mode in enumerate(order):
        rr=[r for r in closed if r['model']==model and r['mode']==mode]
        vals=np.array([float(r['macro_f1']) for r in rr]); lo=np.array([float(r['bootstrap_ci_low']) for r in rr]); hi=np.array([float(r['bootstrap_ci_high']) for r in rr])
        x=i+(j-.5)*.18
        ax.errorbar([x]*len(vals),vals,yerr=[vals-lo,hi-vals],fmt='o',ms=3.1,color=col,alpha=.45,elinewidth=.65,capsize=1.5,zorder=2)
        ax.scatter(x,vals.mean(),s=34,color=col,edgecolor='white',linewidth=.6,zorder=3)
ax.set_xticks(xpos,labels);ax.set_ylim(0,1.05);ax.set_ylabel('Macro-F1 (group bootstrap 95% CI)');ax.set_title('Internal scores exceed cross-source scores',loc='left',weight='normal')
ax.grid(axis='y',color='#D9DEE5',lw=.5);ax.set_axisbelow(True)
ax.legend(handles=[Line2D([0],[0],marker='o',color='w',markerfacecolor=blue,label='ResNet-50',markersize=5),Line2D([0],[0],marker='o',color='w',markerfacecolor=orange,label='ViT-B/16',markersize=5)],frameon=False,loc='lower left')
ax.text(-.12,1.04,'a',transform=ax.transAxes,weight='bold',fontsize=11)

ax=axs[1]
methods={'maximum_softmax_probability':'MSP','energy_score':'Energy','feature_distance':'Feature distance'}
for model,col in [('resnet50',blue),('vit_b_16',orange)]:
    for method,label in methods.items():
        rr=[r for r in opened if r['model']==model and r['method']==method]
        x=np.array([float(r['known_test_acceptance']) for r in rr]);y=np.array([float(r['final_unknown_recall']) for r in rr])
        marker='o' if method=='maximum_softmax_probability' else ('s' if method=='energy_score' else '^')
        ax.scatter(x,y,s=22,marker=marker,color=col,alpha=.55,edgecolor='white',linewidth=.35)
        ax.scatter(x.mean(),y.mean(),s=62,marker=marker,color=col,edgecolor='black',linewidth=.5,zorder=3)
ax.set_xlim(0,1);ax.set_ylim(0,1);ax.set_xlabel('Known-test acceptance');ax.set_ylabel('Final-unknown recall');ax.set_title('Unknown recall trades off against known coverage',loc='left',weight='normal',fontsize=8.5);ax.grid(color='#D9DEE5',lw=.5);ax.set_axisbelow(True)
ax.text(-.12,1.04,'b',transform=ax.transAxes,weight='bold',fontsize=11)
ax.legend(handles=[Line2D([0],[0],marker='o',color='w',markerfacecolor=blue,label='ResNet-50',markersize=5),Line2D([0],[0],marker='o',color='w',markerfacecolor=orange,label='ViT-B/16',markersize=5),Line2D([0],[0],marker='o',color='0.3',linestyle='None',label='MSP',markersize=4),Line2D([0],[0],marker='s',color='0.3',linestyle='None',label='Energy',markersize=4),Line2D([0],[0],marker='^',color='0.3',linestyle='None',label='Feature distance',markersize=4)],frameon=False,loc='lower left',ncol=2,columnspacing=.8,handletextpad=.3)
fig.tight_layout(w_pad=2.0)
fig.savefig(OUT/'Figure1_reliability.png',dpi=600)
fig.savefig(OUT/'Figure1_reliability.pdf')
fig.savefig(OUT/'Figure1_reliability.svg')
print(OUT/'Figure1_reliability.png')
