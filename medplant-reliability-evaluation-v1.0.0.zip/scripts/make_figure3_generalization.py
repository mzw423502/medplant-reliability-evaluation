from pathlib import Path
import csv
import numpy as np
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
STAT=ROOT/'04_关键结果账本'/'v2_paper_statistics'
OUT=ROOT/'08_重绘主图'/'Figure3_generalization'; OUT.mkdir(parents=True,exist_ok=True)
def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
r=read(STAT/'closed_set_run_statistics.csv'); s=read(STAT/'closed_set_model_mode_summary.csv')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'savefig.dpi':600,'axes.spines.top':False,'axes.spines.right':False})
blue='#1764A5'; orange='#D97706'
fig,axs=plt.subplots(1,2,figsize=(7.0,3.05),gridspec_kw={'width_ratios':[1.05,1.25]})
ax=axs[0]; models=['resnet50','vit_b_16']; modes=['combined_group_split','748f_to_nnyt','nnyt_to_748f']; xlabels=['Combined\ninternal','748f → nnyt','nnyt → 748f']
mat=np.array([[float(next(q['mean_macro_f1'] for q in s if q['model']==m and q['mode']==mode)) for mode in modes] for m in models])
im=ax.imshow(mat,cmap='YlGnBu',vmin=0,vmax=1,aspect='auto'); ax.set_xticks(range(3),xlabels); ax.set_yticks(range(2),['ResNet-50','ViT-B/16']); ax.set_title('Cross-source performance is direction-dependent',loc='left',weight='normal',fontsize=8.5); ax.set_xlabel('Training → test scenario'); ax.set_ylabel('Model')
for i in range(2):
    for j in range(3): ax.text(j,i,f'{mat[i,j]:.2f}',ha='center',va='center',color='white' if mat[i,j]<.55 else '#17212B',weight='bold')
fig.colorbar(im,ax=ax,fraction=.045,pad=.03,label='Mean macro-F1'); ax.text(-.18,1.04,'a',transform=ax.transAxes,weight='bold',fontsize=11)
ax=axs[1]
for model,col in [('resnet50',blue),('vit_b_16',orange)]:
    for seed in [20260817,20260818,20260819]:
        rr=[q for q in r if q['model']==model and int(q['seed'])==seed]; d={q['mode']:float(q['macro_f1']) for q in rr}; ax.plot(range(3),[d[m] for m in modes],'-o',color=col,alpha=.38,ms=3,lw=.8)
    rr=[q for q in s if q['model']==model]; d={q['mode']:float(q['mean_macro_f1']) for q in rr}; ax.plot(range(3),[d[m] for m in modes],'-o',color=col,lw=2.2,ms=5,label=model.replace('_','-').title())
ax.set_xticks(range(3),xlabels); ax.set_ylim(0,1.05); ax.set_ylabel('Macro-F1'); ax.set_title('Seed-level results preserve the ranking',loc='left',weight='normal',fontsize=8.5); ax.grid(axis='y',color='#D9DEE5',lw=.5); ax.set_axisbelow(True); ax.legend(frameon=False,loc='upper right'); ax.text(-.14,1.04,'b',transform=ax.transAxes,weight='bold',fontsize=11)
fig.tight_layout(w_pad=2.0); fig.savefig(OUT/'Figure3_generalization.png',dpi=600); fig.savefig(OUT/'Figure3_generalization.pdf'); fig.savefig(OUT/'Figure3_generalization.svg'); print(OUT/'Figure3_generalization.png')
