from __future__ import annotations

import csv
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / "03_数据与代码审计"
SEED = "medplant-open-set-additions-v2-2026-08-18"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def binomial_name(value: str) -> str:
    tokens = re.findall(r"[A-Za-z]+", value)
    if len(tokens) < 2:
        return ""
    return f"{tokens[0].lower()} {tokens[1].lower()}"


species = read_csv(AUDIT / "自采数据规范化物种汇总.csv")
images = read_csv(AUDIT / "自采数据规范化图像清单.csv")
v1 = read_csv(AUDIT / "自采开放集物种分区_v1.csv")
strict_public = read_csv(ROOT / "results" / "strict_shared_species_counts.csv")
public_names = {binomial_name(row["accepted_scientific_name"]) for row in strict_public}

# Scientific labels are used only to carry forward already frozen roles across
# the derived-ID rebase. No role is inferred from taxonomy.
old_role_by_scientific = {row["scientific_name_as_supplied"]: row["open_set_role"] for row in v1}
if len(old_role_by_scientific) != len(v1):
    raise RuntimeError("v1 scientific labels are not unique; cannot preserve roles safely")

new_species = [row for row in species if row["scientific_name_as_supplied"] not in old_role_by_scientific]
new_breadth = [row for row in new_species if row["collection_tier"] == "three_plant_breadth"]
ranked_breadth = sorted(
    new_breadth,
    key=lambda row: hashlib.sha256(f"{SEED}|{row['scientific_name_as_supplied']}".encode()).hexdigest(),
)
new_calibration_names = {row["scientific_name_as_supplied"] for row in ranked_breadth[:2]}

species_rows: list[dict[str, object]] = []
for row in species:
    output = dict(row)
    scientific = row["scientific_name_as_supplied"]
    if scientific in old_role_by_scientific:
        role = old_role_by_scientific[scientific]
        origin = "PRESERVED_FROM_V1_BY_SCIENTIFIC_LABEL"
    else:
        role = "unknown_calibration" if scientific in new_calibration_names else "unknown_final_test"
        origin = "NEW_SPECIES_PREASSIGNED_V2_BEFORE_MODEL_EVALUATION"
    output["deterministic_rank"] = hashlib.sha256(f"{SEED}|{scientific}".encode()).hexdigest()
    output["binomial_name_for_overlap_screen"] = binomial_name(scientific)
    output["strict_public_known_string_overlap"] = output["binomial_name_for_overlap_screen"] in public_names
    output["open_set_role"] = role
    output["role_origin"] = origin
    output["split_version"] = "self-open-set-v2"
    output["split_seed"] = SEED
    output["status"] = "FROZEN_PREANALYSIS_PENDING_FINAL_TAXONOMY_CHECK"
    species_rows.append(output)

role_by_species = {str(row["canonical_species_id"]): str(row["open_set_role"]) for row in species_rows}
image_rows: list[dict[str, object]] = []
for row in images:
    output = dict(row)
    output["open_set_role"] = role_by_species[row["canonical_species_id"]]
    output["split_version"] = "self-open-set-v2"
    image_rows.append(output)

roles_by_leaf: dict[str, set[str]] = defaultdict(set)
roles_by_hash: dict[str, set[str]] = defaultdict(set)
for row in image_rows:
    roles_by_leaf[str(row["physical_leaf_id"])].add(str(row["open_set_role"]))
    roles_by_hash[str(row["sha256"])].add(str(row["open_set_role"]))
leaf_leaks = sum(len(roles) > 1 for roles in roles_by_leaf.values())
hash_leaks = sum(len(roles) > 1 for roles in roles_by_hash.values())
if leaf_leaks or hash_leaks:
    raise RuntimeError(f"v2 split leakage: leaf={leaf_leaks}, hash={hash_leaks}")

# Assert that all 60 old scientific labels retain their v1 role.
preservation_errors = [
    row for row in species_rows
    if row["scientific_name_as_supplied"] in old_role_by_scientific
    and row["open_set_role"] != old_role_by_scientific[row["scientific_name_as_supplied"]]
]
if preservation_errors:
    raise RuntimeError("One or more v1 roles changed")

write_csv(AUDIT / "自采开放集物种分区_v2.csv", sorted(species_rows, key=lambda row: str(row["canonical_species_id"])))
write_csv(AUDIT / "自采开放集图像分区_v2.csv", sorted(image_rows, key=lambda row: str(row["canonical_image_id"])))

role_species = Counter(str(row["open_set_role"]) for row in species_rows)
role_images = Counter(str(row["open_set_role"]) for row in image_rows)
role_groups: dict[str, set[str]] = defaultdict(set)
for row in image_rows:
    role_groups[str(row["open_set_role"])].add(str(row["physical_leaf_id"]))
summary = {
    "split_version": "self-open-set-v2",
    "seed_for_new_species_only": SEED,
    "v1_species_roles_preserved": len(v1),
    "new_species_preassigned": len(new_species),
    "new_species_calibration": sum(row["scientific_name_as_supplied"] in new_calibration_names for row in new_species),
    "new_species_final_test": len(new_species) - sum(row["scientific_name_as_supplied"] in new_calibration_names for row in new_species),
    "species_by_role": dict(role_species),
    "physical_leaf_groups_by_role": {role: len(groups) for role, groups in role_groups.items()},
    "images_by_role": dict(role_images),
    "physical_leaf_group_cross_role_leaks": leaf_leaks,
    "sha256_cross_role_leaks": hash_leaks,
    "strict_public_binomial_string_overlaps": sum(bool(row["strict_public_known_string_overlap"]) for row in species_rows),
    "taxonomy_gate": "final accepted-name comparison still required before formal evaluation",
}
(AUDIT / "自采开放集分区摘要_v2.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(summary, ensure_ascii=False))
