from pathlib import Path
import csv,json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'08_重绘主图'/'Figure2_leakage'; OUT.mkdir(parents=True,exist_ok=True)
audit=json.loads((ROOT/'results'/'hash_audit_summary.json').read_text(encoding='utf-8'))
sens=[]
with (ROOT/'results'/'t9_threshold_sensitivity.csv').open(encoding='utf-8-sig',newline='') as f:sens=list(csv.DictReader(f))
core=[]
with (ROOT/'03_数据与代码审计'/'公共核心近重复阈值敏感性_v1.csv').open(encoding='utf-8-sig',newline='') as f:core=list(csv.DictReader(f))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':600})
blue='#1764A5'; orange='#D97706'; teal='#008C95'; gray='#59636E'
fig,axs=plt.subplots(1,3,figsize=(8.4,2.8),gridspec_kw={'width_ratios':[.95,1.15,1.25]})
ax=axs[0]; labels=['Exact\nduplicates','Cross-split\nduplicates','T9 raw','T9 augmented']; vals=[audit['exact_duplicate_groups'],audit['cross_split_exact_groups'],audit['t9_raw'],audit['t9_augmented']]; colors=[gray,orange,teal,'#B8C1CC']; x=np.arange(4); ax.bar(x,vals,color=colors,width=.68); ax.set_xticks(x,labels); ax.set_yscale('log'); ax.set_ylabel('Count (log scale)'); ax.set_title('Leakage channels are measurable',loc='left',weight='normal'); ax.grid(axis='y',color='#D9DEE5',lw=.5); ax.set_axisbelow(True); ax.text(-.14,1.04,'a',transform=ax.transAxes,weight='bold',fontsize=11)
for i,v in enumerate(vals):ax.text(i,v*1.15,f'{v:,}',ha='center',va='bottom',fontsize=7)
ax.tick_params(axis='x',labelrotation=25)
ax=axs[1]; thresholds=np.array([int(r['threshold']) for r in sens]); ph=np.array([int(r['phash_matches']) for r in sens]); both=np.array([int(r['phash_and_dhash_matches']) for r in sens]); ax.plot(thresholds,ph,'o-',color=blue,label='pHash only');ax.plot(thresholds,both,'s-',color=orange,label='pHash + dHash');ax.axvline(6,color=gray,ls='--',lw=.8);ax.text(6.15,max(ph)*.7,'chosen\nguard',fontsize=7,color=gray);ax.set_xlabel('Hash distance threshold');ax.set_ylabel('Candidate pairs');ax.set_title('Near-duplicate calls depend on threshold',loc='left',weight='normal',fontsize=8.5);ax.legend(frameon=False);ax.grid(color='#D9DEE5',lw=.5);ax.set_axisbelow(True);ax.text(-.14,1.04,'b',transform=ax.transAxes,weight='bold',fontsize=11)
ax=axs[2]
for dataset,color,label in [('748f8jkphb_v3',blue,'748f'),('nnytj2v3n5_v1',orange,'nnyt')]:
 r=[q for q in core if q['dataset_id']==dataset]; t=np.array([int(q['threshold_both_phash_dhash']) for q in r]); c=np.array([int(q['candidate_pairs']) for q in r]); ax.plot(t,c,'o-',color=color,label=label)
ax.axvline(6,color=gray,ls='--',lw=.8);ax.set_xlabel('Hash distance threshold');ax.set_ylabel('Candidate pairs');ax.set_title('Conservative guard limits risk',loc='left',weight='normal');ax.legend(frameon=False);ax.grid(color='#D9DEE5',lw=.5);ax.set_axisbelow(True);ax.text(-.14,1.04,'c',transform=ax.transAxes,weight='bold',fontsize=11)
fig.tight_layout(w_pad=2.2);fig.savefig(OUT/'Figure2_leakage.png',dpi=600);fig.savefig(OUT/'Figure2_leakage.pdf');fig.savefig(OUT/'Figure2_leakage.svg');print(OUT/'Figure2_leakage.png')
