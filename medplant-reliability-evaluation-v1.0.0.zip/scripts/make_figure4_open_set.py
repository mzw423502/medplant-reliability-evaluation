from pathlib import Path
import csv
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
ROOT=Path(__file__).resolve().parents[1]; OPEN=ROOT/'gpu_handoff_return_2026-08-18'/'06_open_set_reaudit_v2'; OUT=ROOT/'08_重绘主图'/'Figure4_open_set'; OUT.mkdir(parents=True,exist_ok=True)
with (OPEN/'final_metrics_all_runs.csv').open(encoding='utf-8-sig',newline='') as f:r=list(csv.DictReader(f))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,'savefig.dpi':600,'axes.spines.top':False,'axes.spines.right':False})
blue='#1764A5'; orange='#D97706'; methods={'maximum_softmax_probability':('MSP','o'),'temperature_scaled_msp':('Temp-MSP','D'),'energy_score':('Energy','s'),'feature_distance':('Feature distance','^')}; modes={'748f_to_nnyt':.45,'nnyt_to_748f':.8,'combined_group_split':1.0}
fig,axs=plt.subplots(1,2,figsize=(7.0,3.05),gridspec_kw={'width_ratios':[1.15,1]})
ax=axs[0]
for model,col in [('resnet50',blue),('vit_b_16',orange)]:
 for method,(label,marker) in methods.items():
  q=[x for x in r if x['model']==model and x['method']==method]
  for row in q: ax.scatter(float(row['known_test_acceptance']),float(row['final_unknown_recall']),s=35,marker=marker,color=col,alpha=modes[row['mode']],edgecolor='white',linewidth=.35)
  x=np.mean([float(row['known_test_acceptance']) for row in q]); y=np.mean([float(row['final_unknown_recall']) for row in q]); ax.scatter(x,y,s=82,marker=marker,color=col,edgecolor='black',linewidth=.6,zorder=4)
ax.set_xlim(0,1);ax.set_ylim(0,1);ax.set_xlabel('Known-test acceptance');ax.set_ylabel('Final-unknown recall');ax.set_title('Open-set performance is a coverage–risk trade-off',loc='left',weight='normal',fontsize=8.5);ax.grid(color='#D9DEE5',lw=.5);ax.set_axisbelow(True);ax.text(-.14,1.04,'a',transform=ax.transAxes,weight='bold',fontsize=11)
ax.legend(handles=[Line2D([0],[0],marker='o',color='w',markerfacecolor=blue,label='ResNet-50',markersize=5),Line2D([0],[0],marker='o',color='w',markerfacecolor=orange,label='ViT-B/16',markersize=5),Line2D([0],[0],marker='o',color='0.3',linestyle='None',label='MSP',markersize=4),Line2D([0],[0],marker='D',color='0.3',linestyle='None',label='Temperature-scaled MSP',markersize=4),Line2D([0],[0],marker='s',color='0.3',linestyle='None',label='Energy score',markersize=4),Line2D([0],[0],marker='^',color='0.3',linestyle='None',label='Feature distance',markersize=4)],frameon=False,loc='lower left',ncol=2,columnspacing=.8,handletextpad=.3)
ax=axs[1]
for model,col in [('resnet50',blue),('vit_b_16',orange)]:
 for method,(label,marker) in methods.items():
  q=[x for x in r if x['model']==model and x['method']==method]; vals=np.array([float(x['final_joint_oscr']) for x in q]); x=list(methods).index(method)+(0 if model=='resnet50' else .34); ax.scatter([x]*len(vals),vals,color=col,alpha=.45,s=20,marker=marker); ax.scatter(x,vals.mean(),color=col,edgecolor='black',linewidth=.5,s=55,marker=marker,zorder=3)
ax.set_xticks(np.arange(4)+.17,['MSP','Temp-MSP','Energy','Feature\ndistance']);ax.set_ylim(0,1);ax.set_ylabel('OSCR');ax.set_title('OSCR across models and scoring methods',loc='left',weight='normal',fontsize=8.5);ax.grid(axis='y',color='#D9DEE5',lw=.5);ax.set_axisbelow(True);ax.text(-.14,1.04,'b',transform=ax.transAxes,weight='bold',fontsize=11);ax.legend(handles=[Line2D([0],[0],marker='o',color='w',markerfacecolor=blue,label='ResNet-50',markersize=5),Line2D([0],[0],marker='o',color='w',markerfacecolor=orange,label='ViT-B/16',markersize=5)],frameon=False,loc='upper right')
fig.tight_layout(w_pad=2.0);fig.savefig(OUT/'Figure4_open_set.png',dpi=600);fig.savefig(OUT/'Figure4_open_set.pdf');fig.savefig(OUT/'Figure4_open_set.svg');print(OUT/'Figure4_open_set.png')
