from pathlib import Path
import csv,json
from collections import defaultdict
import numpy as np
ROOT=Path(__file__).resolve().parents[1]; RUN=ROOT/'gpu_handoff_return_2026-08-18'/'04_primary_runs'; OPEN=ROOT/'gpu_handoff_return_2026-08-18'/'06_open_set_reaudit_v2'; OUT=ROOT/'04_关键结果账本'/'v2_paper_statistics'; MODELS=['resnet50','vit_b_16']; SEEDS=[20260817,20260818,20260819]; MODES=['748f_to_nnyt','nnyt_to_748f','combined_group_split']
def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(p,rows):
 with p.open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def metrics(rows,lab):
 tp=sum(r['true_label']==lab and r['predicted_label']==lab for r in rows); fn=sum(r['true_label']==lab and r['predicted_label']!=lab for r in rows); fp=sum(r['true_label']!=lab and r['predicted_label']==lab for r in rows); rec=tp/(tp+fn) if tp+fn else 0; pre=tp/(tp+fp) if tp+fp else 0; f=2*pre*rec/(pre+rec) if pre+rec else 0; return pre,rec,f,tp+fn
def boot_recall(rows,lab,n=2000,seed=1):
 strata=defaultdict(list)
 for r in rows:
  if r['true_label']==lab:strata[r['near_duplicate_group_id']].append(r)
 rng=np.random.default_rng(seed); vals=[]; keys=list(strata)
 for _ in range(n):
  sample=[x for k in rng.choice(keys,size=len(keys),replace=True) for x in strata[str(k)]]; vals.append(np.mean([int(x['predicted_label']==lab) for x in sample]) if sample else np.nan)
 return float(np.quantile(vals,.025)),float(np.quantile(vals,.975))
public=read(ROOT/'03_数据与代码审计'/'公共核心图像分区_v1.csv'); labels=sorted({r['accepted_scientific_name'] for r in public})
species=[]; matrices={}
for model in MODELS:
 for seed in SEEDS:
  for mode in MODES:
   rows=read(RUN/model/f'seed_{seed}'/mode/'test_predictions.csv'); matrix=np.zeros((len(labels),len(labels)),int); idx={x:i for i,x in enumerate(labels)}
   for r in rows:
    matrix[idx[r['true_label']],idx[r['predicted_label']]]+=1
   matrices[f'{model}_{seed}_{mode}']=matrix
   for lab in labels:
    pre,rec,f,sup=metrics(rows,lab); lo,hi=boot_recall(rows,lab,seed=seed+idx[lab]); species.append({'model':model,'seed':seed,'scenario':mode,'species':lab,'support':sup,'precision':pre,'recall':rec,'f1':f,'recall_bootstrap_ci_low':lo,'recall_bootstrap_ci_high':hi,'bootstrap_replicates':2000,'bootstrap_unit':'near_duplicate_group_id'})
write(OUT/'PER_SPECIES_PERFORMANCE_FULL.csv',species)
for mode in MODES:
 for model in MODELS:
  mats=[matrices[f'{model}_{seed}_{mode}'] for seed in SEEDS]; mean=np.mean(mats,axis=0); norm=mean/mean.sum(axis=1,keepdims=True).clip(min=1); rows=[]
  for i,a in enumerate(labels):
   for j,b in enumerate(labels): rows.append({'model':model,'scenario':mode,'true_species':a,'predicted_species':b,'mean_raw_count':mean[i,j],'row_normalized_mean':norm[i,j]})
  write(OUT/f'CONFUSION_{model}_{mode}.csv',rows)
open_rows=read(OPEN/'final_metrics_all_runs.csv'); write(OUT/'OPENSET_RESULTS_BY_SCENARIO_FULL.csv',open_rows)
summary=[]
for model in MODELS:
 for mode in MODES:
  for method in sorted({r['method'] for r in open_rows}):
   q=[r for r in open_rows if r['model']==model and r['mode']==mode and r['method']==method]; out={'model':model,'scenario':mode,'method':method,'n_seed_runs':len(q)}
   for f in ['final_joint_auroc','final_joint_aupr','final_joint_fpr95','final_joint_oscr','known_test_acceptance','final_unknown_recall']:
    x=np.array([float(z[f]) for z in q]);out[f+'_mean']=float(x.mean());out[f+'_sd']=float(x.std(ddof=1))
   summary.append(out)
write(OUT/'OPENSET_RESULTS_BY_SCENARIO_SUMMARY.csv',summary)
(OUT/'SPECIES_ERROR_ANALYSIS.md').write_text('# Species error analysis\n\nGenerated full per-species precision, recall, F1 and group-bootstrap recall CI for all 11 strict shared species across 18 runs. Confusion matrices are mean raw and row-normalized matrices across the three seeds for each model×scenario. Interpretation is descriptive; no morphological cause is inferred.\n',encoding='utf-8')
print(json.dumps({'status':'SPECIES_OPEN_TABLES_COMPLETE','species_rows':len(species),'open_full_rows':len(open_rows),'open_summary_rows':len(summary)},ensure_ascii=False))
