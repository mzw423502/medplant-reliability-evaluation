from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / "03_数据与代码审计"
CORE = AUDIT / "公共跨数据集核心图像清单_v1.csv"
CANDIDATES = AUDIT / "公共核心近重复候选_v1.csv"
SEED = "public-core-group-split-v1-2026-08-17"
THRESHOLD = 6


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str] | None = None) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields or list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


class UnionFind:
    def __init__(self, values: list[str]) -> None:
        self.parent = {value: value for value in values}

    def find(self, value: str) -> str:
        while self.parent[value] != value:
            self.parent[value] = self.parent[self.parent[value]]
            value = self.parent[value]
        return value

    def union(self, left: str, right: str) -> None:
        left_root = self.find(left)
        right_root = self.find(right)
        if left_root != right_root:
            self.parent[max(left_root, right_root)] = min(left_root, right_root)


images = read_csv(CORE)
candidates = read_csv(CANDIDATES)
paths = [row["path"] for row in images]
path_set = set(paths)
uf = UnionFind(paths)

# Exact duplicates are certain edges. Perceptual edges are deliberately called
# split guards: they prevent leakage but do not assert a shared physical leaf.
by_sha: dict[str, list[str]] = defaultdict(list)
for row in images:
    by_sha[row["sha256"]].append(row["path"])
for duplicate_paths in by_sha.values():
    for path in duplicate_paths[1:]:
        uf.union(duplicate_paths[0], path)

edge_rows: list[dict[str, object]] = []
for row in candidates:
    if int(row["phash_distance"]) > THRESHOLD or int(row["dhash_distance"]) > THRESHOLD:
        continue
    left, right = row["left_path"], row["right_path"]
    if left not in path_set or right not in path_set:
        raise RuntimeError("Candidate path is absent from the core manifest")
    uf.union(left, right)
    dataset = row["dataset_id"]
    edge_rows.append({
        "dataset_id": dataset,
        "accepted_scientific_name": row["accepted_scientific_name"],
        "left_path": left,
        "right_path": right,
        "left_sha256": row["left_sha256"],
        "right_sha256": row["right_sha256"],
        "phash_distance": row["phash_distance"],
        "dhash_distance": row["dhash_distance"],
        "edge_type": "review_supported_near_duplicate_guard" if dataset == "748f8jkphb_v3" else "conservative_similarity_split_guard_not_duplicate_claim",
        "threshold_rule": "phash_distance<=6 AND dhash_distance<=6",
    })

component_members: dict[str, list[str]] = defaultdict(list)
for path in paths:
    component_members[uf.find(path)].append(path)

component_id_by_path: dict[str, str] = {}
component_rows: list[dict[str, object]] = []
image_by_path = {row["path"]: row for row in images}
for members in component_members.values():
    members = sorted(members)
    component_id = "guard:" + hashlib.sha256("\n".join(members).encode()).hexdigest()[:16]
    datasets = {image_by_path[path]["dataset_id"] for path in members}
    species = {image_by_path[path]["accepted_scientific_name"] for path in members}
    if len(datasets) != 1 or len(species) != 1:
        raise RuntimeError(f"Guard component crosses dataset/species: {component_id}")
    for path in members:
        component_id_by_path[path] = component_id
    component_rows.append({
        "guard_component_id": component_id,
        "dataset_id": next(iter(datasets)),
        "accepted_scientific_name": next(iter(species)),
        "image_count": len(members),
        "member_paths": "|".join(members),
        "interpretation": "split_guard_component_not_physical_leaf_id",
    })

components_by_stratum: dict[tuple[str, str], list[dict[str, object]]] = defaultdict(list)
for row in component_rows:
    components_by_stratum[(str(row["dataset_id"]), str(row["accepted_scientific_name"]))].append(row)

split_by_component: dict[str, str] = {}
for stratum, components in sorted(components_by_stratum.items()):
    for component in components:
        component_id = str(component["guard_component_id"])
        digest = hashlib.sha256(f"{SEED}|{stratum[0]}|{stratum[1]}|{component_id}".encode()).digest()
        fraction = int.from_bytes(digest[:8], "big") / 2**64
        split = "train" if fraction < 0.70 else "validation" if fraction < 0.85 else "internal_test"
        split_by_component[component_id] = split

output_images: list[dict[str, object]] = []
for row in images:
    output = dict(row)
    component_id = component_id_by_path[row["path"]]
    output["near_duplicate_group_id"] = component_id
    output["formal_split"] = split_by_component[component_id]
    output["split_version"] = "public-core-group-split-v1"
    output["split_seed"] = SEED
    output["group_interpretation"] = "conservative_split_guard_not_physical_leaf_id"
    output_images.append(output)

component_splits = defaultdict(set)
sha_splits = defaultdict(set)
for row in output_images:
    component_splits[str(row["near_duplicate_group_id"])].add(str(row["formal_split"]))
    sha_splits[str(row["sha256"])].add(str(row["formal_split"]))
component_leaks = sum(len(splits) > 1 for splits in component_splits.values())
sha_leaks = sum(len(splits) > 1 for splits in sha_splits.values())
if component_leaks or sha_leaks:
    raise RuntimeError(f"Leakage after split: components={component_leaks}, sha={sha_leaks}")

for row in component_rows:
    row["formal_split"] = split_by_component[str(row["guard_component_id"])]

write_csv(AUDIT / "公共核心保守分组边_v1.csv", edge_rows)
write_csv(AUDIT / "公共核心保守分组分量_v1.csv", sorted(component_rows, key=lambda row: str(row["guard_component_id"])))
write_csv(AUDIT / "公共核心图像分区_v1.csv", sorted(output_images, key=lambda row: str(row["path"])))

split_counts = Counter((row["dataset_id"], row["formal_split"]) for row in output_images)
summary = {
    "split_version": "public-core-group-split-v1",
    "seed": SEED,
    "perceptual_split_guard_rule": "phash_distance<=6 AND dhash_distance<=6 within dataset and accepted species",
    "threshold_basis": "146-pair manual montage review plus threshold sensitivity analysis; dataset-specific visual behavior documented",
    "interpretation_limit": "components are duplicate/near-duplicate or conservative similarity split guards, never physical leaf IDs",
    "images": len(output_images),
    "guard_edges": len(edge_rows),
    "guard_components": len(component_rows),
    "non_singleton_components": sum(int(row["image_count"]) > 1 for row in component_rows),
    "largest_component_images": max(int(row["image_count"]) for row in component_rows),
    "images_by_dataset_and_split": {f"{dataset}:{split}": count for (dataset, split), count in sorted(split_counts.items())},
    "component_cross_split_leaks": component_leaks,
    "sha256_cross_split_leaks": sha_leaks,
    "external_evaluation_rule": "when one public source is the external test domain, all of that source is held out regardless of within-source split",
}
(AUDIT / "公共核心分区摘要_v1.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(summary, ensure_ascii=False))
