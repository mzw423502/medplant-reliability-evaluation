from __future__ import annotations

import csv
import hashlib
import math
from collections import Counter, defaultdict
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps

ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / "03_数据与代码审计"
CORE = AUDIT / "公共跨数据集核心图像清单_v1.csv"
THRESHOLDS = [0, 2, 4, 6, 8, 10, 12, 16]


def hamming(left: str, right: str) -> int:
    return (int(left, 16) ^ int(right, 16)).bit_count()


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str] | None = None) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields or list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


with CORE.open(encoding="utf-8-sig", newline="") as stream:
    images = list(csv.DictReader(stream))

groups = defaultdict(list)
for row in images:
    groups[(row["dataset_id"], row["accepted_scientific_name"])].append(row)

candidates: list[dict[str, object]] = []
sensitivity_counter = Counter()
for (dataset, species), rows in sorted(groups.items()):
    for i, left in enumerate(rows):
        for right in rows[i + 1:]:
            pd = hamming(left["phash64"], right["phash64"])
            dd = hamming(left["dhash64"], right["dhash64"])
            for threshold in THRESHOLDS:
                if pd <= threshold and dd <= threshold:
                    sensitivity_counter[(dataset, threshold)] += 1
            if pd <= 16 and dd <= 16:
                candidates.append({
                    "dataset_id": dataset,
                    "accepted_scientific_name": species,
                    "left_path": left["path"],
                    "right_path": right["path"],
                    "left_sha256": left["sha256"],
                    "right_sha256": right["sha256"],
                    "phash_distance": pd,
                    "dhash_distance": dd,
                    "max_distance": max(pd, dd),
                    "sum_distance": pd + dd,
                    "review_status": "PENDING_MANUAL_REVIEW",
                })

candidates.sort(key=lambda row: (int(row["max_distance"]), int(row["sum_distance"]), str(row["dataset_id"]), str(row["left_path"]), str(row["right_path"])))
write_csv(AUDIT / "公共核心近重复候选_v1.csv", candidates)

sensitivity = []
for dataset in sorted({row["dataset_id"] for row in images}):
    for threshold in THRESHOLDS:
        sensitivity.append({
            "dataset_id": dataset,
            "threshold_both_phash_dhash": threshold,
            "candidate_pairs": sensitivity_counter[(dataset, threshold)],
        })
write_csv(AUDIT / "公共核心近重复阈值敏感性_v1.csv", sensitivity)

# Deterministic review sample: all very close pairs plus boundary samples per band/dataset.
review: list[dict[str, object]] = []
seen = set()
for row in candidates:
    key = (row["left_sha256"], row["right_sha256"])
    if int(row["max_distance"]) <= 6 and key not in seen:
        review.append(row.copy())
        seen.add(key)
for dataset in sorted({row["dataset_id"] for row in candidates}):
    for low, high in [(7, 8), (9, 10), (11, 12), (13, 16)]:
        band = [row for row in candidates if row["dataset_id"] == dataset and low <= int(row["max_distance"]) <= high]
        band.sort(key=lambda row: hashlib.sha256(f"{row['left_sha256']}|{row['right_sha256']}".encode()).hexdigest())
        for row in band[:8]:
            key = (row["left_sha256"], row["right_sha256"])
            if key not in seen:
                review.append(row.copy())
                seen.add(key)
for index, row in enumerate(review, 1):
    row["review_id"] = f"R{index:03d}"
write_csv(AUDIT / "公共核心近重复人工复核样本_v1.csv", review, fields=["review_id"] + list(candidates[0]))

font = ImageFont.load_default()
cell_w, cell_h = 440, 250
thumb_w, thumb_h = 205, 185
cols = 2
rows_per_page = 8
pages = math.ceil(len(review) / (cols * rows_per_page))
montage_dir = AUDIT / "公共核心近重复人工复核蒙太奇"
montage_dir.mkdir(exist_ok=True)
for page_index in range(pages):
    canvas = Image.new("RGB", (cols * cell_w, rows_per_page * cell_h), "white")
    draw = ImageDraw.Draw(canvas)
    page_rows = review[page_index * cols * rows_per_page:(page_index + 1) * cols * rows_per_page]
    for local_index, row in enumerate(page_rows):
        col = local_index % cols
        line = local_index // cols
        x, y = col * cell_w, line * cell_h
        for side, path_key in enumerate(["left_path", "right_path"]):
            with Image.open(ROOT / str(row[path_key])) as image:
                image = ImageOps.exif_transpose(image).convert("RGB")
                image.thumbnail((thumb_w, thumb_h))
                px = x + side * (cell_w // 2) + ((cell_w // 2) - image.width) // 2
                py = y + 32 + (thumb_h - image.height) // 2
                canvas.paste(image, (px, py))
        title = f"{row['review_id']} {row['dataset_id']} p={row['phash_distance']} d={row['dhash_distance']}"
        draw.text((x + 6, y + 6), title, fill="black", font=font)
        draw.text((x + 6, y + 220), str(row["accepted_scientific_name"]), fill="black", font=font)
        draw.rectangle((x, y, x + cell_w - 1, y + cell_h - 1), outline="#888888", width=1)
    canvas.save(montage_dir / f"page_{page_index + 1:02d}.jpg", quality=92)

print({
    "core_images": len(images),
    "within_dataset_species_groups": len(groups),
    "candidates_both_le16": len(candidates),
    "manual_review_pairs": len(review),
    "montage_pages": pages,
})
