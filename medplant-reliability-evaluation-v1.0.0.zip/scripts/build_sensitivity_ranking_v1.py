from pathlib import Path
import csv,json
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
OPEN=ROOT/'gpu_handoff_return_2026-08-18'/'06_open_set_reaudit_v2'
OUT=ROOT/'04_关键结果账本'/'v2_paper_statistics'
MODELS=['resnet50','vit_b_16']; SEEDS=[20260817,20260818,20260819]; MODES=['748f_to_nnyt','nnyt_to_748f','combined_group_split']; METHODS=['maximum_softmax_probability','temperature_scaled_msp','energy_score','feature_distance']
def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def write(p,rows):
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
open_rows=read(OPEN/'final_metrics_all_runs.csv'); sens=[]
for r in open_rows:
    run=r['run_id']; method=r['method']; d=OPEN/'runs'/run
    val=read(d/'known_validation_scores.csv'); final=read(d/'unknown_final_scores_v2.csv')
    col={'maximum_softmax_probability':'msp_score','temperature_scaled_msp':'temperature_scaled_msp_score','energy_score':'energy_score','feature_distance':'feature_distance'}[method]
    known=np.array([float(x[col]) for x in val]); unknown=np.array([float(x[col]) for x in final]); primary=float(r['threshold_from_calibration']); spread=np.percentile(np.r_[known,unknown],75)-np.percentile(np.r_[known,unknown],25)
    grid=np.unique(primary+spread*np.array([-.5,-.25,0,.25,.5]))
    for t in grid:
        sens.append({'run_id':run,'model':r['model'],'seed':r['seed'],'scenario':r['mode'],'method':method,'threshold':float(t),'known_test_acceptance_primary_reference':float(r['known_test_acceptance']),'final_unknown_recall_primary_reference':float(r['final_unknown_recall']),'known_validation_acceptance':float(np.mean(known<t)),'unknown_calibration_recall':float(np.mean(unknown>=t)),'threshold_offset_iqr_units':float((t-primary)/spread) if spread else 0})
write(OUT/'OPENSET_THRESHOLD_SENSITIVITY_FULL.csv',sens)
(OUT/'OPENSET_THRESHOLD_SENSITIVITY.md').write_text('# Open-set threshold sensitivity\n\nEach run uses a five-point grid centered on the frozen v2 calibration threshold, with offsets of -0.5, -0.25, 0, +0.25 and +0.5 pooled-score IQR units. The primary threshold remains unchanged; this is a sensitivity analysis only.\n',encoding='utf-8')
closed=read(OUT/'closed_set_run_statistics.csv'); rank=[]
for seed in SEEDS:
    for mode in MODES:
        q={x['model']:float(x['macro_f1']) for x in closed if int(x['seed'])==seed and x['mode']==mode}; rank.append({'context':mode,'seed':seed,'metric':'closed_macro_f1','resnet50_value':q['resnet50'],'vit_b_16_value':q['vit_b_16'],'resnet50_rank':1 if q['resnet50']>=q['vit_b_16'] else 2,'vit_b_16_rank':1 if q['vit_b_16']>=q['resnet50'] else 2})
for seed in SEEDS:
    for mode in MODES:
        for metric in ['final_joint_auroc','final_joint_aupr','final_joint_oscr','known_test_acceptance','final_unknown_recall']:
            for method in METHODS:
                q={x['model']:float(x[metric]) for x in open_rows if int(x['seed'])==seed and x['mode']==mode and x['method']==method}; rank.append({'context':mode,'seed':seed,'metric':metric+'_'+method,'resnet50_value':q['resnet50'],'vit_b_16_value':q['vit_b_16'],'resnet50_rank':1 if q['resnet50']>=q['vit_b_16'] else 2,'vit_b_16_rank':1 if q['vit_b_16']>=q['resnet50'] else 2})
write(OUT/'MODEL_RANKING_STABILITY.csv',rank)
summary=[]
for metric in sorted({r['metric'] for r in rank}):
    q=[r for r in rank if r['metric']==metric]; wins=sum(int(r['resnet50_rank']==1) for r in q); summary.append({'metric':metric,'contexts':len(q),'resnet50_wins':wins,'vit_b_16_wins':len(q)-wins,'resnet50_stable_across_all_contexts':wins==len(q),'ranking_note':'descriptive only; 3 seeds, no significance claim'})
(OUT/'MODEL_RANKING_STABILITY.md').write_text('# Model ranking stability\n\nRanking is descriptive across seeds, scenarios and metrics; no significance claim is made from three seeds.\n\n'+ '\n'.join(f"- {x['metric']}: ResNet-50 wins {x['resnet50_wins']}/{x['contexts']} contexts" for x in summary),encoding='utf-8')
print(json.dumps({'status':'SENSITIVITY_RANKING_COMPLETE','sensitivity_rows':len(sens),'ranking_rows':len(rank)},ensure_ascii=False))
