from pathlib import Path
import pandas as pd, numpy as np
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'08_重绘主图'/'Figure6_robustness'
OUT.mkdir(parents=True,exist_ok=True)
stats=ROOT/'04_关键结果账本'/'v2_paper_statistics'
v2=ROOT/'gpu_handoff_return_2026-08-18'/'06_open_set_reaudit_v2'/'runs'

# Panel a: recompute threshold trade-off from frozen feature-distance scores.
rows=[]
for d in sorted(v2.iterdir()):
    if not d.is_dir() or not (d/'known_test_scores.csv').exists(): continue
    kt=pd.read_csv(d/'known_test_scores.csv'); uf=pd.read_csv(d/'unknown_final_scores_v2.csv')
    cal=pd.read_csv(d/'unknown_calibration_scores.csv')
    # Frozen primary threshold is the calibration 95th percentile for feature distance.
    thr=float(np.quantile(cal['feature_distance'],0.95))
    grid=np.linspace(thr-0.5*(cal['feature_distance'].quantile(.75)-cal['feature_distance'].quantile(.25)),thr+0.5*(cal['feature_distance'].quantile(.75)-cal['feature_distance'].quantile(.25)),5)
    for t in grid:
        rows.append({'run_id':d.name,'model':d.name.split('_seed')[0],'scenario':d.name.split('_',2)[-1],'threshold':t,
                     'known_test_acceptance':float((kt.feature_distance<t).mean()),
                     'final_unknown_recall':float((uf.feature_distance>t).mean()),'method':'feature_distance'})
trade=pd.DataFrame(rows); trade.to_csv(OUT/'FIGURE6_THRESHOLD_TRADEOFF.csv',index=False)

closed=pd.read_csv(stats/'closed_set_run_statistics.csv')
openf=pd.read_csv(stats/'OPENSET_RESULTS_BY_SCENARIO_FULL.csv')
rank=pd.read_csv(stats/'MODEL_RANKING_STABILITY.csv')
degr=pd.read_csv(stats/'CROSS_SOURCE_DEGRADATION_FULL.csv')

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False})
fig,axs=plt.subplots(2,2,figsize=(10,7),constrained_layout=True)
colors={'resnet50':'#1f77b4','vit_b_16':'#d95f02'}

ax=axs[0,0]
g=trade.groupby('threshold')[['known_test_acceptance','final_unknown_recall']].mean().sort_index()
ax.plot(g.index,g.known_test_acceptance,'o-',label='Known acceptance',color='#1f77b4'); ax.plot(g.index,g.final_unknown_recall,'o-',label='Final unknown recall',color='#d95f02')
ax.set_xlabel('Feature-distance threshold'); ax.set_ylabel('Proportion'); ax.set_title('Threshold trade-off',loc='left'); ax.legend(frameon=False,fontsize=8); ax.grid(axis='y',alpha=.25)

ax=axs[0,1]
contexts=['combined_group_split','748f_to_nnyt','nnyt_to_748f','open-set']
vals=[]
for c in contexts[:3]:
    for m in ['resnet50','vit_b_16']:
        vals.append((c,m,closed[(closed['model']==m)&(closed['mode']==c)]['macro_f1'].mean()))
for m in ['resnet50','vit_b_16']:
    vals.append(('open-set',m,openf[(openf['model']==m)&(openf['method']=='feature_distance')]['final_joint_oscr'].mean()))
df=pd.DataFrame(vals,columns=['context','model','value'])
for m in colors: ax.plot(range(len(contexts)),df[df['model']==m]['value'].to_numpy(),'o-',label=m,color=colors[m])
ax.set_xticks(range(len(contexts)),['Internal','748f→nnyt','nnyt→748f','Open-set']); ax.set_ylabel('Macro-F1 / OSCR'); ax.set_title('Model ranking depends on context',loc='left'); ax.legend(frameon=False,fontsize=8); ax.grid(axis='y',alpha=.25)

ax=axs[1,0]
for m in colors:
    z=degr[degr.model==m]
    for direction,sub in z.groupby('direction'):
        ax.plot(sub.seed.astype(str),sub.relative_degradation_percent,marker='o',label=f'{m} {direction}',color=colors[m],alpha=.75)
ax.set_xlabel('Seed'); ax.set_ylabel('Cross-source degradation (%)'); ax.set_title('Seed robustness',loc='left'); ax.grid(axis='y',alpha=.25); ax.legend(frameon=False,fontsize=7,ncol=2)

ax=axs[1,1]
o=openf[openf.method=='feature_distance'].groupby('model')[['final_joint_auroc','final_joint_oscr','known_test_acceptance','final_unknown_recall']].mean().T
x=np.arange(len(o.index)); w=.36
ax.bar(x-w/2,o['resnet50'],w,label='ResNet-50',color=colors['resnet50']); ax.bar(x+w/2,o['vit_b_16'],w,label='ViT-B/16',color=colors['vit_b_16'])
ax.set_xticks(x,['AUROC','OSCR','Known\nacceptance','Unknown\nrecall']); ax.set_ylim(0,1); ax.set_ylabel('Value'); ax.set_title('Metric robustness',loc='left'); ax.legend(frameon=False,fontsize=8); ax.grid(axis='y',alpha=.25)

for i,ax in enumerate(axs.flat): ax.text(-.12,1.04,'abcd'[i],transform=ax.transAxes,weight='bold',fontsize=11)
for ext,dpi in [('png',600),('pdf',None),('svg',None)]: fig.savefig(OUT/f'Figure6_robustness.{ext}',dpi=dpi,bbox_inches='tight')
fig.savefig(OUT/'Figure6_robustness_visual_qa.png',dpi=150,bbox_inches='tight')
print(OUT)
