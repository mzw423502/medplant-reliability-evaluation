from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / "03_数据与代码审计"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def cross_role_count(rows: list[dict[str, str]], group_field: str, role_field: str) -> int:
    roles: dict[str, set[str]] = defaultdict(set)
    for row in rows:
        roles[row[group_field]].add(row[role_field])
    return sum(len(values) > 1 for values in roles.values())


parser = argparse.ArgumentParser()
parser.add_argument("--self-version", choices=["v1", "v2"], default="v1")
args = parser.parse_args()

public = read_csv(AUDIT / "公共核心图像分区_v1.csv")
self_images = read_csv(AUDIT / f"自采开放集图像分区_{args.self_version}.csv")

errors: list[str] = []
if len(public) != 1972:
    errors.append(f"expected 1972 public images, got {len(public)}")
if len({row['accepted_scientific_name'] for row in public}) != 11:
    errors.append("public core does not contain exactly 11 accepted names")
if len({row['near_duplicate_group_id'] for row in public}) != 1894:
    errors.append("public guard-component count changed from frozen value 1894")

public_group_leaks = cross_role_count(public, "near_duplicate_group_id", "formal_split")
public_sha_leaks = cross_role_count(public, "sha256", "formal_split")
self_leaf_leaks = cross_role_count(self_images, "physical_leaf_id", "open_set_role")
self_sha_leaks = cross_role_count(self_images, "sha256", "open_set_role")
if any([public_group_leaks, public_sha_leaks, self_leaf_leaks, self_sha_leaks]):
    errors.append("one or more frozen group/hash boundaries cross roles")

expected_roles = (
    Counter({"unknown_final_test": 1302, "unknown_calibration": 342})
    if args.self_version == "v1"
    else Counter({"unknown_final_test": 1548, "unknown_calibration": 378})
)
self_roles = Counter(row["open_set_role"] for row in self_images)
if self_roles != expected_roles:
    errors.append(f"self open-set role counts changed: {dict(self_roles)}")

missing_public = [row["path"] for row in public if not (ROOT / row["path"]).is_file()]
missing_zips = sorted({row["source_zip"] for row in self_images if not (ROOT / row["source_zip"]).is_file()})
if missing_public:
    errors.append(f"missing public files: {len(missing_public)}")
if missing_zips:
    errors.append(f"missing self-collection ZIPs: {len(missing_zips)}")

summary = {
    "status": "PASS" if not errors else "FAIL",
    "public_images": len(public),
    "public_species": len({row["accepted_scientific_name"] for row in public}),
    "public_guard_components": len({row["near_duplicate_group_id"] for row in public}),
    "public_component_cross_split_leaks": public_group_leaks,
    "public_sha256_cross_split_leaks": public_sha_leaks,
    "self_version": args.self_version,
    "self_images": len(self_images),
    "self_physical_leaf_cross_role_leaks": self_leaf_leaks,
    "self_sha256_cross_role_leaks": self_sha_leaks,
    "self_roles": dict(self_roles),
    "missing_public_files": len(missing_public),
    "missing_self_zip_files": len(missing_zips),
    "errors": errors,
}
output = AUDIT / f"实验清单冻结验证_{args.self_version}.json"
output.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(summary, ensure_ascii=False))
if errors:
    raise SystemExit(1)
