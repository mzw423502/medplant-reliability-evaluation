from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import platform
import random
import sys
import time
import zipfile
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageOps
from torch import nn
from torch.utils.data import DataLoader, Dataset
from torchvision.models import ResNet18_Weights, resnet18


ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


class FeatureImages(Dataset):
    def __init__(self, rows: list[dict[str, str]], transform, source: str) -> None:
        self.rows = rows
        self.transform = transform
        self.source = source
        self.zip_handles: dict[str, zipfile.ZipFile] = {}

    def __len__(self) -> int:
        return len(self.rows)

    def _load(self, row: dict[str, str]) -> Image.Image:
        if self.source == "public":
            with Image.open(ROOT / row["path"]) as image:
                return ImageOps.exif_transpose(image).convert("RGB")
        path = row["source_zip"]
        if path not in self.zip_handles:
            self.zip_handles[path] = zipfile.ZipFile(ROOT / path)
        payload = self.zip_handles[path].read(row["source_entry"])
        with Image.open(io.BytesIO(payload)) as image:
            return ImageOps.exif_transpose(image).convert("RGB")

    def __getitem__(self, index: int):
        return self.transform(self._load(self.rows[index])), index


@torch.inference_mode()
def extract_features(model: nn.Module, rows: list[dict[str, str]], transform, source: str, batch_size: int) -> np.ndarray:
    loader = DataLoader(FeatureImages(rows, transform, source), batch_size=batch_size, shuffle=False, num_workers=0)
    output = np.empty((len(rows), 512), dtype=np.float32)
    model.eval()
    for images, indices in loader:
        features = model(images).cpu().numpy().astype(np.float32)
        output[indices.numpy()] = features
    return output


def confusion_metrics(truth: np.ndarray, prediction: np.ndarray, probabilities: np.ndarray, classes: int) -> dict[str, float]:
    confusion = np.zeros((classes, classes), dtype=np.int64)
    for left, right in zip(truth, prediction):
        confusion[int(left), int(right)] += 1
    recalls, f1s = [], []
    for index in range(classes):
        tp = confusion[index, index]
        fn = confusion[index].sum() - tp
        fp = confusion[:, index].sum() - tp
        recall = tp / (tp + fn) if tp + fn else 0.0
        precision = tp / (tp + fp) if tp + fp else 0.0
        recalls.append(recall)
        f1s.append(2 * precision * recall / (precision + recall) if precision + recall else 0.0)
    one_hot = np.eye(classes)[truth]
    return {
        "accuracy": float((truth == prediction).mean()),
        "balanced_accuracy": float(np.mean(recalls)),
        "macro_f1": float(np.mean(f1s)),
        "brier_score_multiclass": float(np.mean(np.sum((probabilities - one_hot) ** 2, axis=1))),
    }


def macro_f1(truth: np.ndarray, prediction: np.ndarray, classes: int) -> float:
    return confusion_metrics(truth, prediction, np.eye(classes, dtype=float)[prediction], classes)["macro_f1"]


def stratified_group_bootstrap(
    rows: list[dict[str, str]], truth: np.ndarray, prediction: np.ndarray, classes: int, replicates: int, seed: int
) -> tuple[float, float]:
    strata: dict[str, dict[str, list[int]]] = defaultdict(lambda: defaultdict(list))
    for index, row in enumerate(rows):
        strata[row["accepted_scientific_name"]][row["near_duplicate_group_id"]].append(index)
    rng = np.random.default_rng(seed)
    estimates = np.empty(replicates, dtype=float)
    for replicate in range(replicates):
        sampled: list[int] = []
        for groups in strata.values():
            keys = list(groups)
            chosen = rng.choice(keys, size=len(keys), replace=True)
            for key in chosen:
                sampled.extend(groups[str(key)])
        indices = np.asarray(sampled, dtype=int)
        estimates[replicate] = macro_f1(truth[indices], prediction[indices], classes)
    return float(np.quantile(estimates, 0.025)), float(np.quantile(estimates, 0.975))


def average_precision(labels: np.ndarray, scores: np.ndarray) -> float:
    positives = int(labels.sum())
    order = np.argsort(-scores, kind="stable")
    ranked = labels[order]
    precision = np.cumsum(ranked) / np.arange(1, len(ranked) + 1)
    return float((precision * ranked).sum() / positives)


def auroc(labels: np.ndarray, scores: np.ndarray) -> float:
    order = np.argsort(scores, kind="stable")
    ranks = np.empty(len(scores), dtype=float)
    ranks[order] = np.arange(1, len(scores) + 1)
    positives = labels == 1
    n_pos, n_neg = positives.sum(), (~positives).sum()
    return float((ranks[positives].sum() - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg))


def choose_threshold(labels: np.ndarray, scores: np.ndarray) -> tuple[float, float]:
    candidates = np.unique(scores)
    best_threshold, best_balanced = float(candidates[0]), -1.0
    for threshold in candidates:
        prediction = scores >= threshold
        tpr = float(prediction[labels == 1].mean())
        tnr = float((~prediction[labels == 0]).mean())
        balanced = (tpr + tnr) / 2
        if balanced > best_balanced:
            best_threshold, best_balanced = float(threshold), balanced
    return best_threshold, best_balanced


def fit_head(train_x: np.ndarray, train_y: np.ndarray, val_x: np.ndarray, val_y: np.ndarray, classes: int, config: dict):
    mean = train_x.mean(axis=0)
    scale = train_x.std(axis=0)
    scale[scale < 1e-6] = 1.0
    train_tensor = torch.from_numpy((train_x - mean) / scale)
    val_tensor = torch.from_numpy((val_x - mean) / scale)
    train_labels = torch.from_numpy(train_y).long()
    head = nn.Linear(train_x.shape[1], classes)
    optimizer = torch.optim.AdamW(head.parameters(), lr=float(config["linear_head_learning_rate"]), weight_decay=float(config["linear_head_weight_decay"]))
    criterion = nn.CrossEntropyLoss()
    best_state, best_score, best_epoch = None, -math.inf, 0
    stale = 0
    for epoch in range(1, int(config["linear_head_epochs_max"]) + 1):
        head.train()
        optimizer.zero_grad(set_to_none=True)
        loss = criterion(head(train_tensor), train_labels)
        loss.backward()
        optimizer.step()
        with torch.inference_mode():
            probs = torch.softmax(head(val_tensor), dim=1).numpy()
        score = confusion_metrics(val_y, probs.argmax(axis=1), probs, classes)["macro_f1"]
        if score > best_score + 1e-12:
            best_score, best_epoch = score, epoch
            best_state = {key: value.detach().clone() for key, value in head.state_dict().items()}
            stale = 0
        else:
            stale += 1
        if stale >= int(config["linear_head_patience"]):
            break
    head.load_state_dict(best_state)
    return head, mean.astype(np.float32), scale.astype(np.float32), best_epoch


def predict(head: nn.Module, features: np.ndarray, mean: np.ndarray, scale: np.ndarray) -> np.ndarray:
    with torch.inference_mode():
        return torch.softmax(head(torch.from_numpy((features - mean) / scale)), dim=1).numpy()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/formal_baseline_resnet18_frozen_v1.json")
    args = parser.parse_args()
    config_path = ROOT / args.config
    config = json.loads(config_path.read_text(encoding="utf-8"))
    if config["status"] != "FROZEN_FOR_FORMAL_BASELINE" or config["run_class"] != "FORMAL_BASELINE_FROZEN_FEATURES":
        raise RuntimeError("Formal baseline config is not frozen")
    public_path = ROOT / config["public_manifest"]
    self_path = ROOT / config["self_manifest"]
    if sha256(public_path) != config["public_manifest_sha256"] or sha256(self_path) != config["self_manifest_sha256"]:
        raise RuntimeError("Frozen manifest hash mismatch")

    seed = int(config["seed"])
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.use_deterministic_algorithms(True)
    public = read_csv(public_path)
    self_rows = read_csv(self_path)
    forbidden = config["forbidden_role_during_model_and_threshold_selection"]
    calibration = [row for row in self_rows if row["open_set_role"] == config["open_set_calibration_role"]]
    if any(row["open_set_role"] == forbidden for row in calibration):
        raise RuntimeError("Final unknown test rows entered calibration extraction")
    classes = sorted({row["accepted_scientific_name"] for row in public})
    label_to_index = {label: index for index, label in enumerate(classes)}
    public_y = np.asarray([label_to_index[row["accepted_scientific_name"]] for row in public], dtype=np.int64)

    output = ROOT / config["output_dir"]
    output.mkdir(parents=True, exist_ok=True)
    cache = output / "feature_cache"
    cache.mkdir(exist_ok=True)
    weights = ResNet18_Weights.IMAGENET1K_V1
    transform = weights.transforms()
    backbone = resnet18(weights=weights)
    backbone.fc = nn.Identity()

    public_cache = cache / "public_resnet18_imagenet1k_v1.npy"
    calibration_cache = cache / "unknown_calibration_resnet18_imagenet1k_v1.npy"
    start = time.time()
    if public_cache.exists():
        public_x = np.load(public_cache)
    else:
        public_x = extract_features(backbone, public, transform, "public", int(config["feature_batch_size"]))
        np.save(public_cache, public_x)
    if calibration_cache.exists():
        calibration_x = np.load(calibration_cache)
    else:
        calibration_x = extract_features(backbone, calibration, transform, "self", int(config["feature_batch_size"]))
        np.save(calibration_cache, calibration_x)

    mode_rows: list[dict[str, object]] = []
    bundles = {}
    datasets = np.asarray([row["dataset_id"] for row in public])
    splits = np.asarray([row["formal_split"] for row in public])
    definitions = {
        "748f_to_nnyt": (
            (datasets == "748f8jkphb_v3") & (splits == "train"),
            (datasets == "748f8jkphb_v3") & (splits == "validation"),
            datasets == "nnytj2v3n5_v1",
        ),
        "nnyt_to_748f": (
            (datasets == "nnytj2v3n5_v1") & (splits == "train"),
            (datasets == "nnytj2v3n5_v1") & (splits == "validation"),
            datasets == "748f8jkphb_v3",
        ),
        "combined_group_split": (splits == "train", splits == "validation", splits == "internal_test"),
    }
    for mode_index, mode in enumerate(config["training_modes"]):
        # Feature extraction and cache hits consume different RNG sequences.
        # Reset per mode so cached and uncached executions fit identical heads.
        random.seed(seed + mode_index)
        np.random.seed(seed + mode_index)
        torch.manual_seed(seed + mode_index)
        train_mask, val_mask, test_mask = definitions[mode]
        head, mean, scale, best_epoch = fit_head(public_x[train_mask], public_y[train_mask], public_x[val_mask], public_y[val_mask], len(classes), config)
        val_probs = predict(head, public_x[val_mask], mean, scale)
        test_probs = predict(head, public_x[test_mask], mean, scale)
        test_prediction = test_probs.argmax(1)
        val_metrics = confusion_metrics(public_y[val_mask], val_probs.argmax(1), val_probs, len(classes))
        test_metrics = confusion_metrics(public_y[test_mask], test_prediction, test_probs, len(classes))
        test_rows = [row for row, selected in zip(public, test_mask) if selected]
        ci_low, ci_high = stratified_group_bootstrap(
            test_rows,
            public_y[test_mask],
            test_prediction,
            len(classes),
            int(config["bootstrap_replicates"]),
            seed + 100 + mode_index,
        )
        mode_rows.append({
            "mode": mode,
            "train_images": int(train_mask.sum()),
            "validation_images": int(val_mask.sum()),
            "test_images": int(test_mask.sum()),
            "best_epoch": best_epoch,
            **{f"validation_{key}": value for key, value in val_metrics.items()},
            **{f"test_{key}": value for key, value in test_metrics.items()},
            "test_macro_f1_bootstrap_ci95_low": ci_low,
            "test_macro_f1_bootstrap_ci95_high": ci_high,
        })
        prediction_rows = []
        for row, truth_value, prediction_value, probs in zip(test_rows, public_y[test_mask], test_prediction, test_probs):
            prediction_rows.append({
                "path": row["path"],
                "dataset_id": row["dataset_id"],
                "near_duplicate_group_id": row["near_duplicate_group_id"],
                "true_label": classes[int(truth_value)],
                "predicted_label": classes[int(prediction_value)],
                "max_softmax": float(probs.max()),
                "correct": int(truth_value == prediction_value),
            })
        with (output / f"test_predictions_{mode}.csv").open("w", encoding="utf-8-sig", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(prediction_rows[0]))
            writer.writeheader()
            writer.writerows(prediction_rows)
        bundle_path = output / f"{mode}_linear_head.pt"
        torch.save({"head": head.state_dict(), "mean": mean, "scale": scale, "classes": classes, "mode": mode}, bundle_path)
        bundles[mode] = (head, mean, scale, train_mask, val_mask)

    head, mean, scale, train_mask, val_mask = bundles["combined_group_split"]
    known_probs = predict(head, public_x[val_mask], mean, scale)
    unknown_probs = predict(head, calibration_x, mean, scale)
    msp_scores = np.concatenate([1 - known_probs.max(1), 1 - unknown_probs.max(1)])
    open_labels = np.concatenate([np.zeros(len(known_probs), dtype=np.int64), np.ones(len(unknown_probs), dtype=np.int64)])

    normalized_train = public_x[train_mask] / np.linalg.norm(public_x[train_mask], axis=1, keepdims=True).clip(min=1e-12)
    centroids = np.stack([normalized_train[public_y[train_mask] == index].mean(axis=0) for index in range(len(classes))])
    centroids /= np.linalg.norm(centroids, axis=1, keepdims=True).clip(min=1e-12)
    known_normalized = public_x[val_mask] / np.linalg.norm(public_x[val_mask], axis=1, keepdims=True).clip(min=1e-12)
    unknown_normalized = calibration_x / np.linalg.norm(calibration_x, axis=1, keepdims=True).clip(min=1e-12)
    distance_scores = np.concatenate([1 - (known_normalized @ centroids.T).max(1), 1 - (unknown_normalized @ centroids.T).max(1)])

    open_results = {}
    for name, scores in {"maximum_softmax_probability": msp_scores, "cosine_distance_to_class_centroid": distance_scores}.items():
        threshold, balanced = choose_threshold(open_labels, scores)
        open_results[name] = {
            "unknown_aupr_calibration": average_precision(open_labels, scores),
            "unknown_auroc_calibration": auroc(open_labels, scores),
            "frozen_threshold": threshold,
            "threshold_balanced_accuracy_calibration": balanced,
        }

    with (output / "closed_set_results.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(mode_rows[0]))
        writer.writeheader()
        writer.writerows(mode_rows)
    (output / "open_set_calibration.json").write_text(json.dumps(open_results, ensure_ascii=False, indent=2), encoding="utf-8")
    report = {
        "run_class": config["run_class"],
        "config": str(config_path.relative_to(ROOT)),
        "config_sha256": sha256(config_path),
        "weights": config["weights"],
        "public_images_featured": len(public),
        "unknown_calibration_images_featured": len(calibration),
        "unknown_final_test_images_loaded": 0,
        "closed_set_results": mode_rows,
        "open_set_calibration": open_results,
        "elapsed_seconds": time.time() - start,
        "environment": {"python": sys.version, "platform": platform.platform(), "torch": torch.__version__, "device": "cpu"},
        "scope_limit": "Frozen-feature ResNet-18 baseline; not a substitute for planned fine-tuned ResNet-50 and ViT primary models.",
    }
    (output / "run_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
