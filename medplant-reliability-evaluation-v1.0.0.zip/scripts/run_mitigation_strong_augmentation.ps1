param(
    [Parameter(Mandatory=$true)][string]$Python,
    [switch]$SmokeOnly
)

$ErrorActionPreference = "Stop"
$root = (Resolve-Path (Join-Path $PSScriptRoot "..\")).Path
$config = "configs/mitigation_strong_augmentation_frozen_v1.json"
$outputRoot = if ($SmokeOnly) {
    "PRESPECIFIED_MITIGATION_EXTENSION/00_smoke_not_for_paper"
} else {
    "PRESPECIFIED_MITIGATION_EXTENSION/01_strong_augmentation_runs"
}

if (-not (Test-Path -LiteralPath $Python)) { throw "Python executable not found: $Python" }
& $Python -c "import torch, torchvision; assert torch.cuda.is_available(); print(torch.__version__, torchvision.__version__, torch.cuda.get_device_name(0))"
if ($LASTEXITCODE -ne 0) { throw "CUDA/PyTorch check failed" }

$models = if ($SmokeOnly) { @("resnet50", "vit_b_16") } else { @("resnet50", "vit_b_16") }
$seeds = if ($SmokeOnly) { @(20260817) } else { @(20260817, 20260818, 20260819) }
$modes = if ($SmokeOnly) { @("combined_group_split") } else { @("748f_to_nnyt", "nnyt_to_748f", "combined_group_split") }

foreach ($model in $models) {
    foreach ($seed in $seeds) {
        foreach ($mode in $modes) {
            $runDir = Join-Path $root "$outputRoot/$model/seed_$seed/$mode"
            $report = Join-Path $runDir "run_report.json"
            if (Test-Path -LiteralPath $report) {
                Write-Output "SKIP completed $model seed=$seed mode=$mode"
                continue
            }
            $arguments = @(
                (Join-Path $root "scripts/run_formal_end_to_end.py"),
                "--config", $config,
                "--model", $model,
                "--seed", "$seed",
                "--mode", $mode,
                "--output-root", $outputRoot
            )
            if ($SmokeOnly) { $arguments += "--smoke" }
            & $Python @arguments
            if ($LASTEXITCODE -ne 0) { throw "Run failed: $model seed=$seed mode=$mode" }
        }
    }
}

Write-Output (if ($SmokeOnly) { "MITIGATION_SMOKE_COMPLETE" } else { "MITIGATION_18_RUNS_COMPLETE" })
